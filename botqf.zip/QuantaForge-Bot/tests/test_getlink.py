import pytest
from bot.getlink_core import GetLinkCore, validate_url


async def test_off_by_default_and_cannot_enable_without_config(ledger):
    g = GetLinkCore(ledger, 200, "")
    assert not await g.is_on()
    assert (await g.start_session(1))[0] == "off"
    ok, _ = await g.set_enabled(True, 99)
    assert not ok
    assert await g.set_url("https://example.com/x", 99)
    ok, _ = await g.set_enabled(True, 99)
    assert not ok  # still no verification secret


def test_url_validation():
    assert validate_url("https://example.com/a")
    assert not validate_url("http://example.com")
    assert not validate_url("javascript:alert(1)")
    assert not validate_url("https://exa mple.com")


async def test_full_flow_and_abuse(ledger):
    g = GetLinkCore(ledger, 200, "s3cret")
    await g.set_url("https://example.com/x", 99)
    assert (await g.set_enabled(True, 99))[0]
    r = await g.start_session(5, now=1000)
    assert r[0] == "ok"
    sid = r[2]
    assert (await g.start_session(5, now=1100))[0] == "cooldown"
    assert await g.verify_session(sid, "forged") is None
    code = await g.verify_session(sid, g.sign(sid), now=1200)
    assert code
    assert (await g.redeem(6, code, now=1300))[0] is False      # wrong user
    assert (await g.redeem(5, "QF-FAKEFAKE", now=1300))[0] is False  # forged
    ok, _, bal = await g.redeem(5, code, now=1300)
    assert ok and bal == 200
    assert (await g.redeem(5, code, now=1301))[0] is False      # reuse
    assert await ledger.balance(5) == 200


async def test_expired_code(ledger):
    g = GetLinkCore(ledger, 200, "s")
    await g.set_url("https://example.com/x", 1); await g.set_enabled(True, 1)
    sid = (await g.start_session(5, now=1000))[2]
    code = await g.verify_session(sid, g.sign(sid), now=1000)
    assert (await g.redeem(5, code, now=1000 + 10_000))[0] is False
    assert await ledger.balance(5) == 0
