import asyncio
from tests.test_matches import mk


async def _fund(ledger, n):
    for u in range(1, n + 1):
        await ledger.credit(u, 1000, "t")


async def test_three_fill_fourth_queues_then_assigned_on_release(ledger, settings):
    c = mk(ledger, settings)
    await _fund(ledger, 8)
    mids = [await c.create("guess", 200, 2 * i + 1, 2 * i + 2) for i in range(4)]
    got = [await c.allocate_next("guess") for _ in range(4)]
    assert [g[1] for g in got[:3]] == [11, 12, 13] and got[3] is None
    assert (await c.get(mids[3]))["status"] == "queued"
    await c.finish(mids[0], 1)
    await c.release(mids[0])
    nxt = await c.allocate_next("guess")
    assert nxt == (mids[3], 11)


async def test_concurrent_allocation_never_double_claims(ledger, settings):
    c = mk(ledger, settings)
    settings.game_channels["word"] = [41]
    await _fund(ledger, 6)
    for i in range(3):
        await c.create("word", 200, 2 * i + 1, 2 * i + 2)
    res = await asyncio.gather(*[c.allocate_next("word") for _ in range(6)])
    assert len([r for r in res if r]) == 1
    assert len(await c.assignments()) == 1


async def test_restart_recovery_policy_refunds_active_once(ledger, settings):
    c = mk(ledger, settings)
    await _fund(ledger, 2)
    mid = await c.create("ttt", 200, 1, 2)
    await c.allocate_next("ttt")
    await c.finish(mid, None, "cancelled", "bot restarted"); await c.release(mid)
    try:
        await c.finish(mid, 1)
        assert False
    except Exception as e:
        assert e.__class__.__name__ == "DuplicateOperation"
    assert await ledger.balance(1) == 1000 and await ledger.balance(2) == 1000
