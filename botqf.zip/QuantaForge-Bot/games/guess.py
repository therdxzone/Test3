class GuessGame:
    def __init__(self, secret: int, players: tuple[int, int], max_guesses: int = 8):
        self.secret, self.players, self.max = secret, players, max_guesses
        self.count = {p: 0 for p in players}
        self.winner = None

    @property
    def exhausted(self) -> bool:
        return all(c >= self.max for c in self.count.values())

    def guess(self, player: int, n):
        """Returns 'invalid' | 'forbidden' | 'out' | 'over' | 'high' | 'low' | 'win'."""
        if player not in self.players:
            return "forbidden"
        if self.winner is not None:
            return "over"
        if not isinstance(n, int) or not 1 <= n <= 100:
            return "invalid"
        if self.count[player] >= self.max:
            return "out"
        self.count[player] += 1
        if n == self.secret:
            self.winner = player
            return "win"
        return "high" if n > self.secret else "low"
