NAMES = {1: "Rock", 2: "Paper", 3: "Scissors"}


class RPSGame:
    def __init__(self, players, target: int = 5):
        self.players, self.target = tuple(players), target
        self.score = {p: 0 for p in players}
        self.moves: dict[int, int] = {}

    def new_round(self):
        self.moves = {}

    def submit(self, player: int, move) -> bool:
        if player not in self.players or move not in NAMES or player in self.moves:
            return False
        self.moves[player] = move
        return True

    def resolve(self):
        """Both moves required. Returns winner id or None (tie); awards the point."""
        a, b = self.players
        if len(self.moves) != 2:
            raise ValueError("round incomplete")
        d = (self.moves[a] - self.moves[b]) % 3
        w = None if d == 0 else (a if d == 1 else b)
        if w:
            self.score[w] += 1
        return w

    def award(self, player: int):
        self.score[player] += 1

    @property
    def winner(self):
        for p, s in self.score.items():
            if s >= self.target:
                return p
        return None
