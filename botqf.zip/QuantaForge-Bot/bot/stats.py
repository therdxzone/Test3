"""Player statistics derived from the matches table (no private moves/guesses are stored)."""
from __future__ import annotations


async def player_stats(db, uid: int) -> dict:
    async with db.execute("SELECT * FROM matches WHERE status IN ('settled','draw') AND (p1=? OR p2=?) ORDER BY match_id",
                          (uid, uid)) as c:
        rows = await c.fetchall()
    st = {"played": len(rows), "wins": 0, "losses": 0, "draws": 0, "cur": 0, "best": 0,
          "wins_by": {}, "losses_by": {}}
    for r in rows:
        g = r["game"]
        if r["status"] == "draw":
            st["draws"] += 1; st["cur"] = 0
        elif r["winner"] == uid:
            st["wins"] += 1; st["cur"] += 1; st["best"] = max(st["best"], st["cur"])
            st["wins_by"][g] = st["wins_by"].get(g, 0) + 1
        else:
            st["losses"] += 1; st["cur"] = 0
            st["losses_by"][g] = st["losses_by"].get(g, 0) + 1
    st["win_pct"] = round(100 * st["wins"] / st["played"], 1) if st["played"] else 0.0
    async with db.execute("SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE user_id=? AND tx_type='match_payout'", (uid,)) as c:
        st["earned"] = (await c.fetchone())["s"]
    async with db.execute("SELECT day,rank,points,reward FROM daily_results WHERE user_id=? ORDER BY day DESC LIMIT 5", (uid,)) as c:
        st["placements"] = await c.fetchall()
    async with db.execute("SELECT COALESCE(SUM(points),0) p FROM daily_points WHERE user_id=? AND day=?", (uid, __import__('bot.match_core', fromlist=['x']).today_ist())) as c:
        st["today_points"] = (await c.fetchone())["p"]
    return st


async def recent_matches(db, uid: int, limit=10):
    async with db.execute("SELECT * FROM matches WHERE (p1=? OR p2=?) AND status IN ('settled','draw','cancelled') "
                          "ORDER BY match_id DESC LIMIT ?", (uid, uid, limit)) as c:
        return await c.fetchall()
