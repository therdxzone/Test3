"""Discord-independent economy logic (daily, message rewards)."""
from __future__ import annotations
import random
import time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from bot.ledger import Ledger, DuplicateOperation


class EconomyCore:
    def __init__(self, ledger: Ledger, settings):
        self.l = ledger
        self.s = settings
        self.tz = ZoneInfo(settings.timezone)

    # ---- daily ----
    def _today(self, now: datetime | None = None) -> str:
        return (now or datetime.now(self.tz)).astimezone(self.tz).date().isoformat()

    def next_reset(self, now: datetime | None = None) -> datetime:
        n = (now or datetime.now(self.tz)).astimezone(self.tz)
        return (n + timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)

    async def claim_daily(self, user_id: int, now: datetime | None = None):
        """Returns (ok, new_balance_or_None, next_reset). Date is the unique claim key."""
        today = self._today(now)
        nxt = self.next_reset(now)
        db = self.l.db

        async def mark():
            async with db.execute("SELECT last_claim_date FROM daily_rewards WHERE user_id=?", (user_id,)) as c:
                row = await c.fetchone()
            if row and row["last_claim_date"] >= today:
                raise DuplicateOperation("already claimed")
            await db.execute(
                "INSERT INTO daily_rewards(user_id,last_claim_date,last_claim_at) VALUES (?,?,?)"
                " ON CONFLICT(user_id) DO UPDATE SET last_claim_date=excluded.last_claim_date,"
                " last_claim_at=excluded.last_claim_at",
                (user_id, today, (now or datetime.now(self.tz)).isoformat()))
        try:
            res = await self.l.transact(
                [dict(user_id=user_id, delta=self.s.daily_reward, tx_type="daily", related_id=today)], extra=mark)
            return True, res[0][1], nxt
        except DuplicateOperation:
            return False, None, nxt

    # ---- message rewards ----
    async def count_message(self, user_id: int, now: float | None = None) -> bool:
        now = now if now is not None else time.time()
        async with self.l._lock:
            db = self.l.db
            await db.execute("INSERT OR IGNORE INTO message_progress(user_id) VALUES (?)", (user_id,))
            cur = await db.execute(
                "UPDATE message_progress SET counted_messages=counted_messages+1, last_counted_at=?"
                " WHERE user_id=? AND ?-last_counted_at >= ?", (now, user_id, now, self.s.msg_cooldown))
            return cur.rowcount == 1

    async def progress(self, user_id: int):
        async with self.l.db.execute(
                "SELECT counted_messages, claimed_batches FROM message_progress WHERE user_id=?", (user_id,)) as c:
            r = await c.fetchone()
        counted, claimed = (r["counted_messages"], r["claimed_batches"]) if r else (0, 0)
        unlocked = counted // self.s.msg_batch
        return counted, claimed, unlocked - claimed, counted % self.s.msg_batch

    async def claim_messages(self, user_id: int, rng: random.Random | None = None):
        rng = rng or random
        counted, claimed, avail, _ = await self.progress(user_id)
        if avail <= 0:
            return None
        batch = claimed + 1
        base = rng.randint(self.s.claim_min, self.s.claim_max)
        bonus = rng.randint(self.s.bonus_min, self.s.bonus_max) if rng.random() < self.s.msg_bonus_chance else 0
        db = self.l.db

        async def mark():
            await db.execute(
                "INSERT INTO message_claims(user_id,batch_no,base_reward,bonus_reward) VALUES (?,?,?,?)",
                (user_id, batch, base, bonus))  # PK blocks a second claim of the same batch
            cur = await db.execute(
                "UPDATE message_progress SET claimed_batches=? WHERE user_id=? AND claimed_batches=?",
                (batch, user_id, claimed))
            if cur.rowcount != 1:
                raise DuplicateOperation("batch already claimed")
        try:
            res = await self.l.transact(
                [dict(user_id=user_id, delta=base + bonus, tx_type="msg_claim", related_id=f"batch{batch}")],
                extra=mark)
        except Exception as e:  # IntegrityError or Duplicate
            if isinstance(e, DuplicateOperation) or e.__class__.__name__ == "IntegrityError":
                return None
            raise
        return base, bonus, res[0][1]
