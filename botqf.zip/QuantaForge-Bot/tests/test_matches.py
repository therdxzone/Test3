import asyncio
import pytest
from bot.match_core import MatchCore, Busy, fee_for, validate_pot
from bot.ledger import DuplicateOperation, InsufficientFunds


def mk(ledger, settings):
    settings.game_channels = {"guess": [11, 12, 13], "rps": [21, 22, 23], "ttt": [31, 32, 33], "word": [41, 42, 43]}
    return MatchCore(ledger, settings)


def test_fee_schedule():
    assert [fee_for(p) for p in (200, 500, 1000, 2000, 5000, 9000)] == [10, 20, 30, 40, 50, 50]
    assert validate_pot(201, 1000) and validate_pot(50, 1000) and not validate_pot(200, 1000)


async def test_payout_once_and_balances(ledger, settings):
    c = mk(ledger, settings)
    await ledger.credit(1, 500, "t"); await ledger.credit(2, 500, "t")
    mid = await c.create("guess", 200, 1, 2)
    assert await ledger.balance(1) == 400 and await ledger.balance(2) == 400
    assert await c.finish(mid, 1) == 190
    with pytest.raises(DuplicateOperation):
        await c.finish(mid, 1)
    with pytest.raises(DuplicateOperation):
        await c.finish(mid, None)
    assert await ledger.balance(1) == 590 and await ledger.balance(2) == 400


async def test_draw_and_cancel_refund_no_fee(ledger, settings):
    c = mk(ledger, settings)
    await ledger.credit(1, 100, "t"); await ledger.credit(2, 100, "t")
    mid = await c.create("rps", 200, 1, 2)
    await c.finish(mid, None, "draw")
    assert await ledger.balance(1) == 100 and await ledger.balance(2) == 100


async def test_insufficient_and_busy_rollback(ledger, settings):
    c = mk(ledger, settings)
    await ledger.credit(1, 100, "t"); await ledger.credit(2, 50, "t"); await ledger.credit(3, 300, "t")
    with pytest.raises(InsufficientFunds):
        await c.create("ttt", 200, 1, 2)
    assert await ledger.balance(1) == 100  # nothing charged
    await c.create("ttt", 200, 1, 3)
    await ledger.credit(2, 100, "t")
    with pytest.raises(Busy):
        await c.create("word", 200, 3, 2)
    assert await ledger.balance(2) == 150
