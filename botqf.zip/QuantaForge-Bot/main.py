import asyncio
import logging
import sys
import discord
from discord.ext import commands
from config import load_settings, ConfigError
from database.init_db import connect, init_db
from bot.ledger import Ledger
from bot.economy_core import EconomyCore
from bot.getlink_core import GetLinkCore
import os

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("qf")
EXTENSIONS = ["bot.economy", "bot.admin", "bot.getlink", "bot.challenges", "bot.leaderboard", "bot.profile", "bot.invites", "bot.shop"]


class QFBot(commands.Bot):
    def __init__(self, settings):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        super().__init__(command_prefix=["&", "!"], intents=intents, help_command=None)
        self.settings = settings

    async def setup_hook(self):
        self.db = await connect(self.settings.database_path)
        await init_db(self.db)
        self.ledger = Ledger(self.db)
        self.eco = EconomyCore(self.ledger, self.settings)
        self.getlink = GetLinkCore(self.ledger, self.settings.getlink_reward, os.getenv("GETLINK_VERIFY_SECRET", ""))
        for ext in EXTENSIONS:
            await self.load_extension(ext)
        self.add_check(self._guild_check)
        async with self.db.execute("SELECT key,value FROM settings") as c:
            for r in await c.fetchall():
                if hasattr(self.settings, r["key"]):
                    setattr(self.settings, r["key"], int(r["value"]))
                    if r["key"] == "getlink_reward":
                        self.getlink.reward = int(r["value"])

    async def _guild_check(self, ctx):
        if ctx.guild is None or ctx.guild.id != self.settings.guild_id:
            return False
        if ctx.prefix == "!" and ctx.command.qualified_name != "buy":
            return False  # "!" is reserved for the shop
        return True

    async def on_ready(self):
        log.info("Logged in as %s", self.user)
        for g in list(self.guilds):
            if g.id != self.settings.guild_id:
                log.warning("Leaving unauthorized guild %s", g.id)
                await g.leave()

    async def on_guild_join(self, guild):
        if guild.id != self.settings.guild_id:
            await guild.leave()

    async def on_command_error(self, ctx, err):
        if isinstance(err, commands.CommandNotFound):
            return
        if isinstance(err, commands.CheckFailure):
            if ctx.prefix == "!":
                return
            if ctx.guild and ctx.guild.id == self.settings.guild_id:
                await ctx.send(str(err) or "You cannot use this command.")
            return
        if isinstance(err, commands.CommandOnCooldown):
            return await ctx.send(f"Slow down. Try again in {err.retry_after:.0f}s.")
        if isinstance(err, (commands.BadArgument, commands.MissingRequiredArgument)):
            return await ctx.send(f"Invalid usage: {err}")
        log.exception("Unhandled command error in %s", ctx.command, exc_info=err)
        await ctx.send("Something went wrong. It has been logged.")

    async def close(self):
        log.info("Shutting down gracefully")
        if getattr(self, "db", None):
            await self.db.close()
        await super().close()


def main():
    try:
        settings = load_settings()
    except ConfigError as e:
        print(e, file=sys.stderr)
        sys.exit(1)
    QFBot(settings).run(settings.token, log_handler=None)


if __name__ == "__main__":
    main()
