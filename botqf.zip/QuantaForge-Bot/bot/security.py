"""Guild/admin checks and shared helpers."""
from __future__ import annotations
import logging
import discord
from discord.ext import commands

log = logging.getLogger("qf.security")


def guild_only_check(settings):
    async def predicate(ctx: commands.Context) -> bool:
        return ctx.guild is not None and ctx.guild.id == settings.guild_id
    return commands.check(predicate)


def admin_only(settings_getter=None):
    async def predicate(ctx: commands.Context) -> bool:
        if not ctx.bot.settings.is_admin(ctx.author.id):
            raise commands.CheckFailure("This command is for configured administrators only.")
        return True
    return commands.check(predicate)


def is_admin_user(bot, user_id: int) -> bool:
    return bot.settings.is_admin(user_id)


async def admin_log(bot, text: str):
    ch = bot.get_channel(bot.settings.admin_log_channel_id)
    if ch:
        try:
            await ch.send(text[:1900])
        except discord.HTTPException:
            log.exception("failed to write admin log")


def embed(title: str, desc: str = "", color=0x5865F2) -> discord.Embed:
    return discord.Embed(title=title, description=desc, color=color)
