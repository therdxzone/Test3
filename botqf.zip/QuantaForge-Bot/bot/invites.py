import logging
import time
import discord
from discord.ext import commands
from bot.security import embed
from bot.ledger import DuplicateOperation

log = logging.getLogger("qf.invites")


class Invites(commands.Cog):
    """Inviter detection compares invite use counts before/after a join. This is best-effort: vanity URLs, expired
    one-use invites, and simultaneous joins cannot be attributed reliably, and then no reward is given."""

    def __init__(self, bot):
        self.bot = bot
        self.cache: dict[str, tuple[int, int]] = {}  # code -> (uses, inviter_id)

    async def _snapshot(self, guild):
        try:
            invs = await guild.invites()
        except discord.HTTPException:
            log.warning("cannot read invites (needs Manage Server)")
            return None
        return {i.code: (i.uses or 0, i.inviter.id if i.inviter else 0) for i in invs}

    @commands.Cog.listener()
    async def on_ready(self):
        g = self.bot.get_guild(self.bot.settings.guild_id)
        if g:
            self.cache = await self._snapshot(g) or {}

    @commands.Cog.listener()
    async def on_invite_create(self, inv):
        if inv.guild and inv.guild.id == self.bot.settings.guild_id:
            self.cache[inv.code] = (inv.uses or 0, inv.inviter.id if inv.inviter else 0)

    @commands.Cog.listener()
    async def on_invite_delete(self, inv):
        pass  # keep cache entry: a one-use invite deleted on join is attributed from the stale snapshot

    @commands.Cog.listener()
    async def on_member_join(self, member):
        s = self.bot.settings
        if member.guild.id != s.guild_id or member.bot:
            return
        new = await self._snapshot(member.guild)
        if new is None:
            return
        used = [c for c, (u, i) in new.items() if u > self.cache.get(c, (0, i))[0]]
        gone = [c for c in self.cache if c not in new]  # single-use invites vanish
        old = self.cache
        self.cache = new
        cands = used or ([] if len(gone) != 1 else gone)
        if len(cands) != 1:
            return  # ambiguous -> no reward
        code = cands[0]
        inviter = (new.get(code) or old.get(code))[1]
        await self._reward(member, inviter)

    async def _reward(self, member, inviter_id):
        s = self.bot.settings
        if not inviter_id or inviter_id == member.id:
            return
        inv = member.guild.get_member(inviter_id)
        if inv is None or inv.bot:
            return
        age_days = (discord.utils.utcnow() - member.created_at).days
        if age_days < s.invite_min_account_days:
            return  # fake-account farming guard
        db = self.bot.db
        today = time.strftime("%Y-%m-%d", time.gmtime())

        async def mark():
            async with db.execute("SELECT COUNT(*) n FROM invite_rewards WHERE inviter_id=? AND substr(created_at,1,10)=?",
                                  (inviter_id, today)) as c:
                if (await c.fetchone())["n"] >= s.invite_daily_cap:
                    raise DuplicateOperation("daily cap")
            await db.execute("INSERT INTO invite_rewards(invitee_id,join_id,inviter_id,amount) VALUES (?,?,?,?)",
                             (member.id, "first", inviter_id, s.invite_reward))  # PK: one reward per invitee ever
        try:
            await self.bot.ledger.transact([dict(user_id=inviter_id, delta=s.invite_reward, tx_type="invite",
                                                 related_id=str(member.id))], extra=mark)
        except (DuplicateOperation, Exception) as e:
            if not isinstance(e, DuplicateOperation) and e.__class__.__name__ != "IntegrityError":
                log.exception("invite reward failed")

    @commands.command()
    @commands.cooldown(1, 30, commands.BucketType.user)
    async def invite(self, ctx):
        async with self.bot.db.execute("SELECT COUNT(*) n, COALESCE(SUM(amount),0) a FROM invite_rewards WHERE inviter_id=?",
                                       (ctx.author.id,)) as c:
            r = await c.fetchone()
        link = "(could not create — bot needs Create Invite permission)"
        try:
            inv = await ctx.channel.create_invite(max_age=0, max_uses=0, unique=True, reason=f"QF invite for {ctx.author.id}")
            link = inv.url
            self.cache[inv.code] = (0, ctx.author.id)
        except discord.HTTPException:
            pass
        s = self.bot.settings
        await ctx.send(embed=embed("Invite rewards",
            f"Your link: {link}\nReward: **{s.invite_reward} QF** per new member (account ≥ {s.invite_min_account_days} days old, one reward per person ever).\n"
            f"You've earned **{r['a']:,} QF** from {r['n']} invites.\n*Attribution is best-effort; ambiguous joins are not rewarded.*"))


async def setup(bot):
    await bot.add_cog(Invites(bot))
