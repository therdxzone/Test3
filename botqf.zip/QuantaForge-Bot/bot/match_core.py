"""Discord-independent match lifecycle: reserve stakes, queue, channel allocation, settlement."""
from __future__ import annotations
import secrets
from bot.ledger import Ledger, DuplicateOperation, InsufficientFunds


class Busy(Exception):
    pass


def fee_for(pot: int) -> int:
    if pot >= 5000: return 50
    if pot >= 2000: return 40
    if pot >= 1000: return 30
    if pot >= 500: return 20
    return 10


def validate_pot(pot: int, max_stake: int) -> str | None:
    if pot < 100: return "Total pot must be at least 100."
    if pot % 2: return "Total pot must be an even number."
    if pot // 2 > max_stake: return f"Maximum stake per player is {max_stake:,}."
    return None


def today_ist(tz: str = "Asia/Kolkata", now=None) -> str:
    from datetime import datetime
    from zoneinfo import ZoneInfo
    return (now or datetime.now(ZoneInfo(tz))).astimezone(ZoneInfo(tz)).date().isoformat()


async def award_points(db, settings, winner: int, loser: int):
    """Leaderboard points: only for completed, settled wins. Runs inside the settlement transaction.
    Repeat wins against the same opponent beyond the daily cap give no points (anti-farming)."""
    import time
    day = today_ist(settings.timezone)
    await db.execute("INSERT OR IGNORE INTO daily_pair(day,winner,loser) VALUES (?,?,?)", (day, winner, loser))
    await db.execute("UPDATE daily_pair SET wins=wins+1 WHERE day=? AND winner=? AND loser=?", (day, winner, loser))
    async with db.execute("SELECT wins FROM daily_pair WHERE day=? AND winner=? AND loser=?", (day, winner, loser)) as c:
        n = (await c.fetchone())["wins"]
    if n > settings.pair_cap:
        return
    await db.execute("INSERT OR IGNORE INTO daily_points(day,user_id) VALUES (?,?)", (day, winner))
    await db.execute("UPDATE daily_points SET points=points+?, wins=wins+1, last_at=? WHERE day=? AND user_id=?",
                     (settings.win_points, time.time(), day, winner))


class MatchCore:
    def __init__(self, ledger: Ledger, settings):
        self.l, self.s = ledger, settings

    async def get(self, mid: int):
        async with self.l.db.execute("SELECT * FROM matches WHERE match_id=?", (mid,)) as c:
            return await c.fetchone()

    async def user_busy(self, uid: int) -> bool:
        async with self.l.db.execute(
                "SELECT 1 FROM matches WHERE status IN ('queued','active') AND (p1=? OR p2=?)", (uid, uid)) as c:
            return await c.fetchone() is not None

    async def create(self, game: str, pot: int, p1: int, p2: int) -> int:
        """Atomically reserves both stakes and queues the match. Raises Busy / InsufficientFunds."""
        ref, stake, fee = secrets.token_hex(8), pot // 2, fee_for(pot)
        db = self.l.db

        async def mk():
            async with db.execute("SELECT 1 FROM matches WHERE status IN ('queued','active') AND "
                                  "(p1 IN (?,?) OR p2 IN (?,?))", (p1, p2, p1, p2)) as c:
                if await c.fetchone():
                    raise Busy("a player is already in a match")
            await db.execute("INSERT INTO matches(ref,game,pot,stake,fee,p1,p2,status) VALUES (?,?,?,?,?,?,?,'queued')",
                             (ref, game, pot, stake, fee, p1, p2))
        await self.l.transact(
            [dict(user_id=u, delta=-stake, tx_type="match_stake", related_id=ref) for u in (p1, p2)], extra=mk)
        async with db.execute("SELECT match_id FROM matches WHERE ref=?", (ref,)) as c:
            return (await c.fetchone())["match_id"]

    async def allocate_next(self, game: str):
        """Assigns the oldest queued match of `game` to a free configured channel. Returns (match_id, channel_id) or None."""
        db, out = self.l.db, {}

        async def alloc():
            async with db.execute("SELECT match_id FROM matches WHERE status='queued' AND game=? "
                                  "ORDER BY match_id LIMIT 1", (game,)) as c:
                row = await c.fetchone()
            if not row:
                return
            async with db.execute("SELECT channel_id FROM channel_assign") as c:
                used = {r["channel_id"] for r in await c.fetchall()}
            for ch in self.s.game_channels.get(game, []):
                if ch not in used:
                    await db.execute("INSERT INTO channel_assign(channel_id,match_id) VALUES (?,?)", (ch, row["match_id"]))
                    await db.execute("UPDATE matches SET status='active', channel_id=?, started_at=CURRENT_TIMESTAMP "
                                     "WHERE match_id=? AND status='queued'", (ch, row["match_id"]))
                    out["r"] = (row["match_id"], ch)
                    return
        await self.l.transact([], extra=alloc)
        return out.get("r")

    async def finish(self, mid: int, winner: int | None = None, status: str = "settled", note: str = ""):
        """Settles exactly once. winner=None => refund both stakes, no fee. Returns payout (0 if refund).
        Raises DuplicateOperation if already settled."""
        m = await self.get(mid)
        if m is None:
            raise ValueError("unknown match")
        db = self.l.db
        if winner is not None:
            if winner not in (m["p1"], m["p2"]):
                raise ValueError("winner not in match")
            payout = m["pot"] - m["fee"]
            ops = [dict(user_id=winner, delta=payout, tx_type="match_payout", related_id=m["ref"])]
            status = "settled"
        else:
            payout = 0
            ops = [dict(user_id=u, delta=m["stake"], tx_type="match_refund", related_id=m["ref"]) for u in (m["p1"], m["p2"])]
            status = status if status in ("draw", "cancelled") else "draw"

        async def mark():
            cur = await db.execute("UPDATE matches SET status=?, winner=?, note=?, ended_at=CURRENT_TIMESTAMP "
                                   "WHERE match_id=? AND status IN ('queued','active')", (status, winner, note, mid))
            if cur.rowcount != 1:
                raise DuplicateOperation("match already settled")
            if winner is not None:
                await award_points(db, self.s, winner, m["p2"] if winner == m["p1"] else m["p1"])
        await self.l.transact(ops, extra=mark)
        return payout

    async def release(self, mid: int):
        db = self.l.db

        async def rel():
            await db.execute("DELETE FROM channel_assign WHERE match_id=?", (mid,))
        await self.l.transact([], extra=rel)

    async def force_release_channel(self, channel_id: int):
        db = self.l.db

        async def rel():
            await db.execute("DELETE FROM channel_assign WHERE channel_id=?", (channel_id,))
        await self.l.transact([], extra=rel)

    async def list_matches(self, statuses=("queued", "active")):
        q = ",".join("?" * len(statuses))
        async with self.l.db.execute(f"SELECT * FROM matches WHERE status IN ({q}) ORDER BY match_id", statuses) as c:
            return await c.fetchall()

    async def assignments(self):
        async with self.l.db.execute("SELECT * FROM channel_assign") as c:
            return {r["channel_id"]: r["match_id"] for r in await c.fetchall()}
