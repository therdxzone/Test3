# QuantaForge Private Bot (complete)

Private, single-server Discord economy + games bot. Python 3.11+, discord.py 2.x, SQLite (aiosqlite). Prefix `&` (plus `!buy`).
QF Coins are virtual points with no cash value.

## 1. Install on a Linux VPS
    sudo apt update && sudo apt install -y python3 python3-venv python3-pip unzip sqlite3
    unzip QuantaForge-Bot.zip -d /opt && cd /opt/QuantaForge-Bot
    python3 -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    cp .env.example .env && nano .env && chmod 600 .env     # never commit .env
    python -m pytest                                         # optional: run tests
    python main.py                                           # first run creates database/qf_coins.db

## 2. Discord setup
- Developer Portal → Bot: enable **Message Content Intent** and **Server Members Intent**.
- Invite with permissions: View Channels, Send Messages, Embed Links, Read History, Manage Messages, Create Invite, Manage Server
  (to read invite uses for `&invite`). The bot needs **Manage Permissions** only inside the 12 game channels.
- Game channels (12, pre-existing): make each **private** (deny View Channel for @everyone) and grant the bot View, Send,
  Manage Permissions there. The bot refuses to run a match in a channel @everyone can see. It never creates/deletes channels.
- Fill in `.env`: DISCORD_TOKEN, GUILD_ID, OWNER_ID/ADMIN_IDS, the 4 log/result channel IDs, and all 12 game channel IDs.
  Startup prints exactly which settings are wrong.

## 3. Run as a service — `/etc/systemd/system/qfbot.service`
    [Unit]
    Description=QuantaForge bot
    After=network-online.target
    [Service]
    WorkingDirectory=/opt/QuantaForge-Bot
    ExecStart=/opt/QuantaForge-Bot/.venv/bin/python main.py
    Restart=always
    User=qfbot
    [Install]
    WantedBy=multi-user.target
    sudo systemctl daemon-reload && sudo systemctl enable --now qfbot
    journalctl -u qfbot -f          # logs;   sudo systemctl restart qfbot

## 4. Verify
`&help`, `&balance`, `&daily`, `&botstatus` (admin: shows missing channels), `&getlink` (shows COMING SOON), then a test
`&challenge @friend rps 200`. Fill all three channels of one game to see the queue (`&matches`).

## 5. Backup / restore / update
    sqlite3 database/qf_coins.db ".backup '/opt/backups/qf-$(date +%F).db'"   # safe while running
    sudo systemctl stop qfbot && cp /opt/backups/qf-DATE.db database/qf_coins.db && sudo systemctl start qfbot
Update: stop the service, replace code files only (keep `.env` and `database/`), `pip install -r requirements.txt`, start.

## 6. Policies
- **Money safety**: every balance change is one SQLite transaction with a unique key (match ref, day, batch, request ref), so payouts,
  refunds, daily prizes and VPS refunds can't repeat, even after a restart.
- **Matches**: stakes reserved on accept; decline/expiry charges nothing; draw/cancel/crash = full refund, no fee; matches running during
  a restart are cancelled and refunded; queued ones resume. Timeouts: TTT 10s move → forfeit; RPS 3s window (missed = point to the player
  who moved; 3 empty rounds = draw); Word 3 unanswered rounds = draw; Guess 8 guesses each / 5 min → draw.
- **Leaderboard**: 10 points per settled win; wins vs the same opponent beyond 5/day score 0. Rank = points, then wins, then earlier
  to reach score, then lower user ID. Coin spending/admin grants/GetLink/transfers never give points. Resets 12:00 AM Asia/Kolkata;
  prizes 300/200/100 are finalized and paid in one transaction and posted to the leaderboard channel (missed days are caught up).
- **Invites**: best-effort attribution from invite use counts; ambiguous joins, bots, self-invites, accounts < 7 days old, repeat joiners
  (one reward per person ever) and > 20 rewards/day per inviter are not rewarded.
- **GetLink**: OFF by default; needs a URL and `GETLINK_VERIFY_SECRET`; codes only issued after a signed provider callback
  (`GetLinkCore.verify_session(session_id, HMAC-SHA256(session_id, secret))` — you must wire your provider's callback to this).
  Turning OFF blocks new sessions; already-issued unexpired codes stay redeemable. Make sure your ad provider permits rewarded traffic.
- **VPS shop**: `!buy` → choose affordable plan → Confirm → coins reserved → admin Accept/Reject buttons in the request channel.
  Reject refunds once. Accept calls `PROVISION_API_URL` (POST JSON `{request_ref, plan, ram_gb, storage_gb, discord_user_id}`, bearer
  token, `Idempotency-Key` = request_ref; expects 200/201 with `server_id` or `id`). Without that config, or on failure, the request
  becomes **manual** (never reported as created); `&vpsrefund <id>` returns coins for manual requests. Adapt `ShopCore.provision`
  to your real QuantaForge node API or a Pterodactyl panel (its endpoints/auth differ).

## 7. Admin commands
`&addcoins &removecoins &setcoins &giveall &coinlogs &botstatus &matches &releasechannel &addgetlink &getlink on|off|status
&setplan &delplan &vpsrequests &vpsrefund &setconfig <key> <int> &leaderboard daily|history`

## 8. Troubleshooting
- "Invalid configuration" → fix the listed `.env` lines. `LoginFailure` → wrong/rotated token. Commands ignored → Message Content
  Intent off or wrong GUILD_ID. "channel is visible to @everyone" / "needs Manage Permissions" → fix that channel's permissions.
- `database is locked` → only one bot process may use the DB. Corrupt DB → restore the latest backup.
