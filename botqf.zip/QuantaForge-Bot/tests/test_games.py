import random
from games.guess import GuessGame
from games.rps import RPSGame
from games.tictactoe import TTTGame
from games.word_scramble import WordGame


def test_guess():
    g = GuessGame(42, (1, 2), 2)
    assert g.guess(3, 5) == "forbidden" and g.guess(1, 0) == "invalid" and g.guess(1, "x") == "invalid"
    assert g.guess(1, 50) == "high" and g.guess(1, 10) == "low" and g.guess(1, 42) == "out"
    assert g.guess(2, 42) == "win" and g.guess(1, 42) == "over"


def test_rps():
    g = RPSGame((1, 2))
    g.new_round()
    assert g.submit(1, 1) and not g.submit(1, 2) and not g.submit(9, 1) and not g.submit(2, 7)
    assert g.submit(2, 3) and g.resolve() == 1 and g.score[1] == 1   # rock beats scissors
    g.new_round(); g.submit(1, 2); g.submit(2, 2)
    assert g.resolve() is None and g.score == {1: 1, 2: 0}
    for _ in range(5):
        g.new_round(); g.submit(2, 2); g.submit(1, 1); g.resolve()
    assert g.winner == 2


def test_ttt():
    g = TTTGame(1, 2)
    assert not g.move(2, 1)[0]            # out of turn
    assert not g.move(9, 1)[0]            # nonparticipant
    assert g.move(1, 1)[0] and not g.move(2, 1)[0] and not g.move(2, 10)[0]
    for p, pos in ((2, 4), (1, 2), (2, 5), (1, 3)):
        assert g.move(p, pos)[0]
    assert g.winner == 1
    d = TTTGame(1, 2)
    for i, pos in enumerate((1, 2, 3, 5, 4, 6, 8, 7, 9)):
        d.move(1 if i % 2 == 0 else 2, pos)
    assert d.draw and d.winner is None


def test_word_single_point_per_round():
    g = WordGame((1, 2), random.Random(3))
    scr, hint = g.new_round()
    assert scr != g.word and sorted(scr) == sorted(g.word)
    assert not g.answer(3, g.word) and not g.answer(1, "wrong")
    assert g.answer(1, g.word.upper()) and not g.answer(2, g.word)
    assert g.score == {1: 1, 2: 0}
