"""VPS shop logic: plans, reservation, once-only reject/refund, provisioning adapter."""
from __future__ import annotations
import asyncio
import secrets
from bot.ledger import Ledger, DuplicateOperation, InsufficientFunds


class ShopError(Exception):
    pass


class ShopCore:
    def __init__(self, ledger: Ledger, settings):
        self.l, self.s = ledger, settings

    async def plans(self, active_only=True):
        q = "SELECT * FROM vps_plans" + (" WHERE active=1" if active_only else "") + " ORDER BY price"
        async with self.l.db.execute(q) as c:
            return await c.fetchall()

    async def set_plan(self, name, ram, storage, price):
        async def f():
            await self.l.db.execute(
                "INSERT INTO vps_plans(name,ram_gb,storage_gb,price,active) VALUES (?,?,?,?,1) ON CONFLICT(name) DO UPDATE SET "
                "ram_gb=excluded.ram_gb, storage_gb=excluded.storage_gb, price=excluded.price, active=1", (name, ram, storage, price))
        await self.l.transact([], extra=f)

    async def disable_plan(self, name):
        async def f():
            await self.l.db.execute("UPDATE vps_plans SET active=0 WHERE name=? COLLATE NOCASE", (name,))
        await self.l.transact([], extra=f)

    async def get(self, rid):
        async with self.l.db.execute("SELECT * FROM vps_requests WHERE request_id=?", (rid,)) as c:
            return await c.fetchone()

    async def request(self, user_id: int, plan_name: str) -> int:
        """Re-validates balance server-side and reserves coins atomically. One open request per user."""
        db = self.l.db
        async with db.execute("SELECT * FROM vps_plans WHERE name=? COLLATE NOCASE AND active=1", (plan_name,)) as c:
            plan = await c.fetchone()
        if not plan:
            raise ShopError("That plan is not available.")
        ref = "vps-" + secrets.token_hex(8)

        async def mk():
            async with db.execute("SELECT 1 FROM vps_requests WHERE user_id=? AND status IN ('pending','provisioning')", (user_id,)) as c:
                if await c.fetchone():
                    raise ShopError("You already have an open VPS request.")
            await db.execute("INSERT INTO vps_requests(ref,user_id,plan,ram_gb,storage_gb,price,status) VALUES (?,?,?,?,?,?,'pending')",
                             (ref, user_id, plan["name"], plan["ram_gb"], plan["storage_gb"], plan["price"]))
        try:
            await self.l.transact([dict(user_id=user_id, delta=-plan["price"], tx_type="vps_reserve", related_id=ref)], extra=mk)
        except InsufficientFunds:
            raise ShopError("Not enough QF Coins.")
        async with db.execute("SELECT request_id FROM vps_requests WHERE ref=?", (ref,)) as c:
            return (await c.fetchone())["request_id"]

    async def set_message(self, rid, message_id):
        async def f():
            await self.l.db.execute("UPDATE vps_requests SET message_id=? WHERE request_id=?", (message_id, rid))
        await self.l.transact([], extra=f)

    async def reject(self, rid: int, admin_id: int, reason="rejected"):
        """Refunds the reservation exactly once. Raises DuplicateOperation if not pending."""
        r = await self.get(rid)
        if not r:
            raise ShopError("Unknown request.")
        db = self.l.db

        async def mark():
            cur = await db.execute("UPDATE vps_requests SET status='rejected', decided_by=?, decided_at=CURRENT_TIMESTAMP "
                                   "WHERE request_id=? AND status='pending'", (admin_id, rid))
            if cur.rowcount != 1:
                raise DuplicateOperation("not pending")
        await self.l.transact([dict(user_id=r["user_id"], delta=r["price"], tx_type="vps_refund", related_id=r["ref"],
                                    admin_id=admin_id, reason=reason)], extra=mark)

    async def refund_unprovisioned(self, rid: int, admin_id: int):
        """Admin refund for requests stuck in 'manual'. Same once-only refund key."""
        r = await self.get(rid)
        if not r:
            raise ShopError("Unknown request.")
        db = self.l.db

        async def mark():
            cur = await db.execute("UPDATE vps_requests SET status='refunded', decided_by=? WHERE request_id=? AND status='manual'",
                                   (admin_id, rid))
            if cur.rowcount != 1:
                raise DuplicateOperation("not refundable")
        await self.l.transact([dict(user_id=r["user_id"], delta=r["price"], tx_type="vps_refund", related_id=r["ref"],
                                    admin_id=admin_id, reason="manual refund")], extra=mark)

    async def accept(self, rid: int, admin_id: int):
        """Claims the request (pending -> provisioning) once, then provisions. Returns (status, server_id, note)."""
        db = self.l.db
        claimed = {}

        async def mark():
            cur = await db.execute("UPDATE vps_requests SET status='provisioning', decided_by=?, decided_at=CURRENT_TIMESTAMP "
                                   "WHERE request_id=? AND status='pending'", (admin_id, rid))
            claimed["ok"] = cur.rowcount == 1
        await self.l.transact([], extra=mark)
        if not claimed["ok"]:
            raise DuplicateOperation("not pending")
        r = await self.get(rid)
        status, server_id, note = await self.provision(r)

        async def fin():
            await db.execute("UPDATE vps_requests SET status=?, server_id=?, note=? WHERE request_id=?", (status, server_id, note, rid))
        await self.l.transact([], extra=fin)
        return status, server_id, note

    async def provision(self, r):
        """Calls the configured backend. Never reports success unless the backend returns a server id."""
        if not self.s.provision_url:
            return "manual", None, "Provisioning API not configured; create the server manually."
        import aiohttp
        payload = {"request_ref": r["ref"], "plan": r["plan"], "ram_gb": r["ram_gb"], "storage_gb": r["storage_gb"],
                   "discord_user_id": str(r["user_id"])}
        headers = {"Authorization": f"Bearer {self.s.provision_token}", "Idempotency-Key": r["ref"]}
        last = "unknown error"
        for attempt in range(3):
            try:
                async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as s:
                    async with s.post(self.s.provision_url, json=payload, headers=headers) as resp:
                        if resp.status in (200, 201):
                            data = await resp.json()
                            sid = data.get("server_id") or data.get("id")
                            if sid:
                                return "provisioned", str(sid), "ok"
                            last = "backend response had no server id"
                            break
                        last = f"backend returned HTTP {resp.status}"
                        if resp.status < 500:
                            break
            except (aiohttp.ClientError, asyncio.TimeoutError) as e:
                last = f"backend unreachable ({e.__class__.__name__})"
            await asyncio.sleep(2 ** attempt)
        return "manual", None, f"Provisioning failed: {last}. Needs manual handling."
