import logging
import discord
from discord.ext import commands
from bot.security import embed, admin_log, admin_only
from bot.shop_core import ShopCore, ShopError
from bot.ledger import DuplicateOperation

log = logging.getLogger("qf.shop")


class BuyView(discord.ui.View):
    def __init__(self, cog, user_id, plans, balance):
        super().__init__(timeout=120)
        self.cog, self.user_id, self.choice = cog, user_id, None
        opts = [discord.SelectOption(label=p["name"], description=f"{p['ram_gb']}GB RAM / {p['storage_gb']}GB — {p['price']:,} QF")
                for p in plans if p["price"] <= balance][:25]
        if opts:
            sel = discord.ui.Select(placeholder="Choose a plan", options=opts)
            sel.callback = self.pick
            self.add_item(sel)
        else:
            self.confirm.disabled = True

    async def interaction_check(self, itx):
        if itx.user.id != self.user_id:
            await itx.response.send_message("This menu belongs to someone else.", ephemeral=True)
            return False
        return True

    async def pick(self, itx):
        self.choice = itx.data["values"][0]
        await itx.response.send_message(f"Selected **{self.choice}**. Press Confirm.", ephemeral=True)

    @discord.ui.button(label="Confirm", style=discord.ButtonStyle.success)
    async def confirm(self, itx, button):
        if not self.choice:
            return await itx.response.send_message("Pick a plan first.", ephemeral=True)
        await itx.response.defer()
        self.stop()
        try:
            rid = await self.cog.core.request(self.user_id, self.choice)
        except ShopError as e:
            return await itx.edit_original_response(content=str(e), embed=None, view=None)
        await self.cog.post_request(rid)
        await itx.edit_original_response(content=f"Request #{rid} submitted. Coins are reserved until an admin decides.", embed=None, view=None)


class AdminView(discord.ui.View):
    def __init__(self, cog, rid):
        super().__init__(timeout=None)
        self.cog, self.rid = cog, rid
        a = discord.ui.Button(label="Accept", style=discord.ButtonStyle.success, custom_id=f"vps_accept_{rid}")
        r = discord.ui.Button(label="Reject", style=discord.ButtonStyle.danger, custom_id=f"vps_reject_{rid}")
        a.callback, r.callback = self.accept, self.reject
        self.add_item(a); self.add_item(r)

    async def interaction_check(self, itx):
        if not self.cog.bot.settings.is_admin(itx.user.id):
            await itx.response.send_message("Administrators only.", ephemeral=True)
            return False
        return True

    async def accept(self, itx):
        await itx.response.defer()
        try:
            status, sid, note = await self.cog.core.accept(self.rid, itx.user.id)
        except DuplicateOperation:
            return await itx.followup.send("Already decided.", ephemeral=True)
        self.stop()
        await itx.edit_original_response(embed=await self.cog.request_embed(self.rid), view=None)
        await self.cog.notify(self.rid, status, sid, note)
        await admin_log(self.cog.bot, f"[vps] #{self.rid} accepted by {itx.user.id}: {status} {note}")

    async def reject(self, itx):
        await itx.response.defer()
        try:
            await self.cog.core.reject(self.rid, itx.user.id)
        except DuplicateOperation:
            return await itx.followup.send("Already decided.", ephemeral=True)
        self.stop()
        await itx.edit_original_response(embed=await self.cog.request_embed(self.rid), view=None)
        await self.cog.notify(self.rid, "rejected", None, "Your coins were refunded.")
        await admin_log(self.cog.bot, f"[vps] #{self.rid} rejected by {itx.user.id}; refunded")


class Shop(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.core = ShopCore(bot.ledger, bot.settings)

    async def cog_load(self):
        self._restore = True

    @commands.Cog.listener()
    async def on_ready(self):
        if getattr(self, "_restore", False):
            self._restore = False
            async with self.bot.db.execute("SELECT request_id FROM vps_requests WHERE status='pending'") as c:
                for r in await c.fetchall():
                    self.bot.add_view(AdminView(self, r["request_id"]))

    async def request_embed(self, rid):
        r = await self.core.get(rid)
        e = embed(f"VPS request #{rid}", f"User: <@{r['user_id']}>\nPlan: **{r['plan']}** ({r['ram_gb']}GB RAM / {r['storage_gb']}GB)\n"
                  f"Price: {r['price']:,} QF (reserved)\nStatus: **{r['status']}**" +
                  (f"\nServer: `{r['server_id']}`" if r["server_id"] else "") + (f"\nNote: {r['note']}" if r["note"] else ""))
        return e

    async def post_request(self, rid):
        ch = self.bot.get_channel(self.bot.settings.vps_request_channel_id)
        view = AdminView(self, rid)
        if ch is None:
            log.error("VPS request channel missing; request #%s waits for admin", rid)
            return
        msg = await ch.send(embed=await self.request_embed(rid), view=view)
        await self.core.set_message(rid, msg.id)

    async def notify(self, rid, status, sid, note):
        r = await self.core.get(rid)
        user = self.bot.get_user(r["user_id"]) or await self.bot.fetch_user(r["user_id"])
        text = {"provisioned": f"✅ Your VPS **{r['plan']}** was created (server `{sid}`).",
                "manual": f"✅ Request #{rid} approved, but provisioning is **pending/manual**: {note}",
                "rejected": f"❌ Request #{rid} was rejected. {note}"}.get(status, f"Request #{rid}: {status}")
        try:
            await user.send(text)
        except discord.HTTPException:
            pass

    @commands.command()
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def buy(self, ctx):
        plans = await self.core.plans()
        bal = await self.bot.ledger.balance(ctx.author.id)
        lines = [f"{'✅' if bal >= p['price'] else '❌'} **{p['name']}** — {p['ram_gb']}GB RAM, {p['storage_gb']}GB — {p['price']:,} QF" for p in plans]
        await ctx.send(embed=embed("VPS Shop", f"Balance: **{bal:,}** QF\n\n" + "\n".join(lines) +
                       "\n\nChoose an affordable plan and confirm. Coins are reserved; an admin must approve."),
                       view=BuyView(self, ctx.author.id, plans, bal))

    @commands.command()
    @admin_only()
    async def setplan(self, ctx, name: str, ram_gb: int, storage_gb: int, price: int):
        if min(ram_gb, storage_gb, price) <= 0:
            return await ctx.send("Values must be positive.")
        await self.core.set_plan(name, ram_gb, storage_gb, price)
        await self.bot.ledger.audit(ctx.author.id, "setplan", f"{name} {ram_gb} {storage_gb} {price}")
        await ctx.send(f"Plan **{name}** saved.")

    @commands.command()
    @admin_only()
    async def delplan(self, ctx, name: str):
        await self.core.disable_plan(name)
        await self.bot.ledger.audit(ctx.author.id, "delplan", name)
        await ctx.send(f"Plan **{name}** disabled.")

    @commands.command()
    @admin_only()
    async def vpsrefund(self, ctx, request_id: int):
        try:
            await self.core.refund_unprovisioned(request_id, ctx.author.id)
        except (DuplicateOperation, ShopError):
            return await ctx.send("Only requests in 'manual' status can be refunded, once.")
        await ctx.send("Refunded.")

    @commands.command()
    @admin_only()
    async def vpsrequests(self, ctx):
        async with self.bot.db.execute("SELECT * FROM vps_requests ORDER BY request_id DESC LIMIT 15") as c:
            rows = await c.fetchall()
        await ctx.send(embed=embed("VPS requests", "\n".join(f"#{r['request_id']} <@{r['user_id']}> {r['plan']} — {r['status']}" for r in rows) or "None."))

    @commands.command()
    @admin_only()
    async def setconfig(self, ctx, key: str, value: int):
        allowed = {"daily_reward": "daily_reward", "getlink_reward": "getlink_reward", "invite_reward": "invite_reward",
                   "win_points": "win_points", "max_stake": "max_stake"}
        if key not in allowed or value < 0:
            return await ctx.send(f"Keys: {', '.join(allowed)}")
        setattr(self.bot.settings, allowed[key], value)
        if key == "getlink_reward":
            self.bot.getlink.reward = value
        await self.bot.ledger.transact([], extra=lambda: self.bot.db.execute(
            "INSERT INTO settings(key,value,updated_by) VALUES (?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_by=excluded.updated_by",
            (key, str(value), ctx.author.id)))
        await self.bot.ledger.audit(ctx.author.id, "setconfig", f"{key}={value}")
        await ctx.send(f"{key} = {value}")


async def setup(bot):
    await bot.add_cog(Shop(bot))
