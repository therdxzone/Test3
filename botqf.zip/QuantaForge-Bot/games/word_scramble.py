import random
from games.words import WORDS


def scramble(word: str, rng) -> str:
    letters = list(word)
    for _ in range(20):
        rng.shuffle(letters)
        if "".join(letters) != word:
            break
    return "".join(letters)


class WordGame:
    def __init__(self, players, rng=None, words=None, target: int = 5):
        self.players, self.target = tuple(players), target
        self.rng = rng or random.Random()
        self.pool = list(words or WORDS)
        self.rng.shuffle(self.pool)
        self.score = {p: 0 for p in players}
        self.word = self.hint = self.scrambled = None
        self.open = False

    def new_round(self):
        self.word, self.hint = self.pool.pop() if self.pool else self.rng.choice(WORDS)
        self.scrambled = scramble(self.word, self.rng)
        self.open = True
        return self.scrambled, self.hint

    def answer(self, player: int, text: str) -> bool:
        """True only for the first correct answer of an open round."""
        if not self.open or player not in self.players:
            return False
        if text.strip().lower() != self.word:
            return False
        self.open = False
        self.score[player] += 1
        return True

    def close_round(self):
        self.open = False

    @property
    def winner(self):
        for p, s in self.score.items():
            if s >= self.target:
                return p
        return None
