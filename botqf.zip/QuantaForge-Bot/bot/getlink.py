import discord
from discord.ext import commands
from bot.security import embed, admin_only


class GetLink(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.group(invoke_without_command=True)
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def getlink(self, ctx):
        gl = self.bot.getlink
        r = await gl.start_session(ctx.author.id)
        if r[0] == "off":
            return await ctx.send(embed=embed(
                "QUANTAFORGE — GETLINK",
                "🚧 **COMING SOON!**\n\nThe GetLink reward system is currently unavailable.\n\nPlease check back later!"))
        if r[0] == "cooldown":
            return await ctx.send(f"You can start another session in {r[1]//3600}h {(r[1]%3600)//60}m.")
        _, url, sid = r
        await ctx.send(embed=embed("QUANTAFORGE — GETLINK",
            f"1. Open: {url}\n2. Complete the steps.\n3. Redeem your code with `&code YOUR-CODE`.\n"
            f"Reward: **{gl.reward} QF** after verification. Session: `{sid[:8]}`"))

    @getlink.command(name="on")
    @admin_only()
    async def gl_on(self, ctx):
        ok, msg = await self.bot.getlink.set_enabled(True, ctx.author.id)
        await ctx.send("GetLink is now **ON**." if ok else f"Cannot enable: {msg}")

    @getlink.command(name="off")
    @admin_only()
    async def gl_off(self, ctx):
        await self.bot.getlink.set_enabled(False, ctx.author.id)
        await ctx.send("GetLink is now **OFF**. New sessions are blocked; already-issued unexpired codes stay redeemable.")

    @getlink.command(name="status")
    @admin_only()
    async def gl_status(self, ctx):
        c = await self.bot.getlink.config()
        await ctx.send(embed=embed("GetLink status",
            f"State: **{'ON' if c['enabled'] else 'OFF'}**\nLink configured: **{'yes' if c['url'] else 'no'}**\n"
            f"Verification secret configured: **{'yes' if self.bot.getlink.secret else 'no'}**"))

    @commands.command()
    @admin_only()
    async def addgetlink(self, ctx, url: str):
        if not await self.bot.getlink.set_url(url, ctx.author.id):
            return await ctx.send("Invalid URL. It must be a well-formed `https://` link.")
        try:
            await ctx.message.delete()
        except discord.HTTPException:
            pass
        await ctx.send("GetLink URL saved.")

    @commands.command()
    @commands.cooldown(3, 30, commands.BucketType.user)
    async def code(self, ctx, code: str):
        ok, msg, _ = await self.bot.getlink.redeem(ctx.author.id, code)
        await ctx.send(msg)


async def setup(bot):
    await bot.add_cog(GetLink(bot))
