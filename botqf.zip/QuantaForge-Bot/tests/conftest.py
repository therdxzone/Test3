import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import pytest_asyncio
from config import Settings
from database.init_db import connect, init_db
from bot.ledger import Ledger


@pytest_asyncio.fixture
async def ledger(tmp_path):
    db = await connect(str(tmp_path / "t.db"))
    await init_db(db)
    yield Ledger(db)
    await db.close()


@pytest_asyncio.fixture
def settings():
    return Settings()
