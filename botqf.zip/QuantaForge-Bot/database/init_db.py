"""Database initialisation and connection helper."""
from __future__ import annotations
import os
import aiosqlite

_DIR = os.path.dirname(__file__)


async def connect(path: str) -> aiosqlite.Connection:
    d = os.path.dirname(path)
    if d:
        os.makedirs(d, exist_ok=True)
    db = await aiosqlite.connect(path, isolation_level=None)
    db.row_factory = aiosqlite.Row
    await db.execute("PRAGMA foreign_keys = ON")
    await db.execute("PRAGMA journal_mode = WAL")
    await db.execute("PRAGMA busy_timeout = 5000")
    return db


async def init_db(db: aiosqlite.Connection) -> None:
    for name in ("schema.sql", "schema_extra.sql"):
        p = os.path.join(_DIR, name)
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                await db.executescript(f.read())
