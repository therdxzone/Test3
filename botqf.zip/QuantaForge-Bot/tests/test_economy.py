import asyncio, random
from datetime import datetime
from zoneinfo import ZoneInfo
import pytest
from bot.economy_core import EconomyCore
from bot.ledger import InsufficientFunds

IST = ZoneInfo("Asia/Kolkata")


async def test_no_negative_balance(ledger):
    await ledger.credit(1, 50, "x")
    with pytest.raises(InsufficientFunds):
        await ledger.debit(1, 51, "y")
    assert await ledger.balance(1) == 50


async def test_daily_once_per_period(ledger, settings):
    settings.daily_reward = 100
    eco = EconomyCore(ledger, settings)
    d1 = datetime(2026, 10, 25, 10, tzinfo=IST)
    r = await asyncio.gather(*[eco.claim_daily(7, d1) for _ in range(5)])
    assert sum(1 for ok, *_ in r if ok) == 1
    assert await ledger.balance(7) == 100
    ok, *_ = await eco.claim_daily(7, datetime(2026, 10, 25, 23, 59, tzinfo=IST))
    assert not ok
    ok, *_ = await eco.claim_daily(7, datetime(2026, 10, 26, 0, 1, tzinfo=IST))
    assert ok


async def test_message_cooldown_and_single_claim(ledger, settings):
    eco = EconomyCore(ledger, settings)
    assert await eco.count_message(1, now=1000.0)
    assert not await eco.count_message(1, now=1005.0)  # inside 10s
    t = 2000.0
    for _ in range(99):
        assert await eco.count_message(1, now=t); t += 11
    assert (await eco.progress(1))[2] == 1
    rng = random.Random(1)
    rs = await asyncio.gather(*[eco.claim_messages(1, rng) for _ in range(4)])
    assert sum(1 for r in rs if r) == 1
    assert await eco.claim_messages(1, rng) is None
