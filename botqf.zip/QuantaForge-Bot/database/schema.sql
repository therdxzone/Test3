PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  user_id INTEGER PRIMARY KEY,
  balance INTEGER NOT NULL DEFAULT 0 CHECK (balance >= 0),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS transactions (
  tx_id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(user_id),
  amount INTEGER NOT NULL,
  tx_type TEXT NOT NULL,
  prev_balance INTEGER NOT NULL,
  new_balance INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  related_id TEXT,
  admin_id INTEGER,
  reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id, tx_id DESC);
CREATE UNIQUE INDEX IF NOT EXISTS uq_tx_related ON transactions(tx_type, user_id, related_id)
  WHERE related_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS message_progress (
  user_id INTEGER PRIMARY KEY,
  counted_messages INTEGER NOT NULL DEFAULT 0,
  claimed_batches INTEGER NOT NULL DEFAULT 0,
  last_counted_at REAL NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS message_claims (
  user_id INTEGER NOT NULL,
  batch_no INTEGER NOT NULL,
  base_reward INTEGER NOT NULL,
  bonus_reward INTEGER NOT NULL DEFAULT 0,
  claimed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, batch_no)
);
CREATE TABLE IF NOT EXISTS daily_rewards (
  user_id INTEGER PRIMARY KEY,
  last_claim_date TEXT NOT NULL,
  last_claim_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS invite_rewards (
  invitee_id INTEGER NOT NULL,
  join_id TEXT NOT NULL,
  inviter_id INTEGER NOT NULL,
  amount INTEGER NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (invitee_id, join_id)
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_by INTEGER,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS admin_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id INTEGER NOT NULL,
  action TEXT NOT NULL,
  details TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS getlink_config (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  url TEXT,
  enabled INTEGER NOT NULL DEFAULT 0,
  updated_by INTEGER,
  updated_at TEXT
);
INSERT OR IGNORE INTO getlink_config (id, url, enabled) VALUES (1, NULL, 0);
CREATE TABLE IF NOT EXISTS getlink_sessions (
  session_id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at REAL NOT NULL,
  expires_at REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending'
);
CREATE INDEX IF NOT EXISTS idx_gl_user ON getlink_sessions(user_id, created_at DESC);
CREATE TABLE IF NOT EXISTS getlink_codes (
  code_hash TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES getlink_sessions(session_id),
  user_id INTEGER NOT NULL,
  expires_at REAL NOT NULL,
  redeemed_at REAL
);
