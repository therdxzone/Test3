"""Configuration loading and startup validation."""
from __future__ import annotations
import os
from dataclasses import dataclass, field
from dotenv import load_dotenv

GAMES = ("guess", "rps", "ttt", "word")
_PREFIX = {"guess": "GUESS", "rps": "RPS", "ttt": "TTT", "word": "WORD"}


class ConfigError(Exception):
    pass


def _int(name: str, default: int | None = None, errors: list | None = None) -> int:
    raw = os.getenv(name, "").strip()
    if not raw:
        if default is not None:
            return default
        if errors is not None:
            errors.append(f"{name} is missing. Set it in .env (numeric Discord ID).")
        return 0
    try:
        return int(raw)
    except ValueError:
        if errors is not None:
            errors.append(f"{name}='{raw}' is not a number.")
        return 0


@dataclass
class Settings:
    token: str = ""
    guild_id: int = 0
    owner_id: int = 0
    admin_ids: frozenset = frozenset()
    admin_log_channel_id: int = 0
    game_results_channel_id: int = 0
    leaderboard_channel_id: int = 0
    vps_request_channel_id: int = 0
    getlink_reward: int = 200
    database_path: str = "database/qf_coins.db"
    daily_reward: int = 100
    msg_cooldown: int = 10
    msg_batch: int = 100
    msg_bonus_chance: float = 0.25
    claim_min: int = 10
    claim_max: int = 100
    bonus_min: int = 10
    bonus_max: int = 50
    max_stake: int = 100000
    win_points: int = 10
    pair_cap: int = 5
    invite_reward: int = 50
    invite_min_account_days: int = 7
    invite_daily_cap: int = 20
    prize: tuple = (300, 200, 100)
    provision_url: str = ""
    provision_token: str = ""
    timezone: str = "Asia/Kolkata"
    game_channels: dict = field(default_factory=dict)

    def is_admin(self, user_id: int) -> bool:
        return user_id in self.admin_ids or (self.owner_id and user_id == self.owner_id)


def load_settings(validate: bool = True) -> Settings:
    load_dotenv()
    errors: list[str] = []
    s = Settings()
    s.token = os.getenv("DISCORD_TOKEN", "").strip()
    if not s.token:
        errors.append("DISCORD_TOKEN is missing. Create a bot token in the Developer Portal.")
    s.guild_id = _int("GUILD_ID", errors=errors)
    s.owner_id = _int("OWNER_ID", default=0)
    ids = set()
    for part in os.getenv("ADMIN_IDS", "").replace(" ", "").split(","):
        if part:
            if part.isdigit():
                ids.add(int(part))
            else:
                errors.append(f"ADMIN_IDS contains invalid value '{part}'.")
    s.admin_ids = frozenset(ids)
    if not ids and not s.owner_id:
        errors.append("ADMIN_IDS is empty. Provide at least one administrator Discord ID.")
    s.admin_log_channel_id = _int("ADMIN_LOG_CHANNEL_ID", errors=errors)
    s.game_results_channel_id = _int("GAME_RESULTS_CHANNEL_ID", errors=errors)
    s.leaderboard_channel_id = _int("LEADERBOARD_CHANNEL_ID", errors=errors)
    s.vps_request_channel_id = _int("VPS_REQUEST_CHANNEL_ID", errors=errors)
    s.getlink_reward = _int("GETLINK_REWARD_COINS", 200)
    s.daily_reward = _int("DAILY_REWARD", 100)
    s.msg_cooldown = _int("MSG_COOLDOWN_SECONDS", 10)
    s.database_path = os.getenv("DATABASE_PATH", "database/qf_coins.db")
    s.max_stake = _int("MAX_STAKE", 100000)
    s.win_points = _int("WIN_POINTS", 10)
    s.pair_cap = _int("DAILY_PAIR_WIN_CAP", 5)
    s.invite_reward = _int("INVITE_REWARD", 50)
    s.invite_min_account_days = _int("INVITE_MIN_ACCOUNT_DAYS", 7)
    s.invite_daily_cap = _int("INVITE_DAILY_CAP", 20)
    s.provision_url = os.getenv("PROVISION_API_URL", "").strip()
    s.provision_token = os.getenv("PROVISION_API_TOKEN", "").strip()
    try:
        s.msg_bonus_chance = float(os.getenv("MSG_BONUS_CHANCE", "0.25"))
        if not 0 <= s.msg_bonus_chance <= 1:
            raise ValueError
    except ValueError:
        errors.append("MSG_BONUS_CHANCE must be a number between 0 and 1.")
    seen = {}
    for g in GAMES:
        chans = []
        for i in (1, 2, 3):
            name = f"{_PREFIX[g]}_CHANNEL_{i}"
            cid = _int(name, errors=errors)
            if cid:
                if cid in seen:
                    errors.append(f"{name} duplicates {seen[cid]} (a channel can serve only one slot).")
                seen[cid] = name
                chans.append(cid)
        s.game_channels[g] = chans
    if validate and errors:
        raise ConfigError("Invalid configuration:\n - " + "\n - ".join(errors))
    return s
