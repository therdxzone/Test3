"""GetLink logic. OFF by default. Rewards only after provider-verified completion.

Verification model (provider-agnostic): when a user starts a session, the bot stores a pending
session. Your verification provider/callback must call `verify_session(session_id, signature)`
with an HMAC-SHA256 signature of the session id using GETLINK_VERIFY_SECRET. Only then is a
one-time code issued. The code is stored as a hash, bound to user + session, expires, and is
redeemable once. No verification secret configured => feature cannot be turned ON.
"""
from __future__ import annotations
import hashlib
import hmac
import secrets
import time
from urllib.parse import urlparse
from bot.ledger import Ledger, DuplicateOperation

SESSION_TTL = 3600
CODE_TTL = 900
COOLDOWN = 24 * 3600


def validate_url(url: str) -> bool:
    if len(url) > 500 or any(ch.isspace() for ch in url):
        return False
    p = urlparse(url)
    return p.scheme == "https" and bool(p.netloc) and "." in p.netloc


def _h(code: str) -> str:
    return hashlib.sha256(code.strip().upper().encode()).hexdigest()


class GetLinkCore:
    def __init__(self, ledger: Ledger, reward: int, verify_secret: str = ""):
        self.l = ledger
        self.reward = reward
        self.secret = verify_secret

    async def config(self):
        async with self.l.db.execute("SELECT * FROM getlink_config WHERE id=1") as c:
            return await c.fetchone()

    async def is_on(self) -> bool:
        c = await self.config()
        return bool(c["enabled"]) and bool(c["url"]) and bool(self.secret)

    async def set_url(self, url: str, admin_id: int) -> bool:
        if not validate_url(url):
            return False
        await self.l.db.execute(
            "UPDATE getlink_config SET url=?, updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=1", (url, admin_id))
        await self.l.audit(admin_id, "getlink_set_url", "url updated")
        return True

    async def set_enabled(self, on: bool, admin_id: int):
        """Returns (ok, message)."""
        if on:
            c = await self.config()
            if not c["url"]:
                return False, "No GetLink URL configured. Use `&addgetlink <https-url>` first."
            if not self.secret:
                return False, "GETLINK_VERIFY_SECRET is not configured; no verification provider is set up."
        await self.l.db.execute(
            "UPDATE getlink_config SET enabled=?, updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=1",
            (1 if on else 0, admin_id))
        await self.l.audit(admin_id, "getlink_on" if on else "getlink_off")
        return True, "ON" if on else "OFF"

    async def start_session(self, user_id: int, now: float | None = None):
        """Returns ('ok', url, session_id) | ('off',) | ('cooldown', seconds_left)."""
        now = now or time.time()
        if not await self.is_on():
            return ("off",)
        async with self.l._lock:
            db = self.l.db
            async with db.execute("SELECT MAX(created_at) m FROM getlink_sessions WHERE user_id=?", (user_id,)) as c:
                last = (await c.fetchone())["m"]
            if last and now - last < COOLDOWN:
                return ("cooldown", int(COOLDOWN - (now - last)))
            sid = secrets.token_urlsafe(16)
            await db.execute("INSERT INTO getlink_sessions(session_id,user_id,created_at,expires_at) VALUES (?,?,?,?)",
                             (sid, user_id, now, now + SESSION_TTL))
        return ("ok", (await self.config())["url"], sid)

    def sign(self, session_id: str) -> str:
        return hmac.new(self.secret.encode(), session_id.encode(), hashlib.sha256).hexdigest()

    async def verify_session(self, session_id: str, signature: str, now: float | None = None):
        """Called by the trusted provider callback. Returns the one-time code, or None."""
        now = now or time.time()
        if not self.secret or not hmac.compare_digest(self.sign(session_id), signature or ""):
            return None
        async with self.l._lock:
            db = self.l.db
            async with db.execute("SELECT * FROM getlink_sessions WHERE session_id=?", (session_id,)) as c:
                s = await c.fetchone()
            if not s or s["status"] != "pending" or s["expires_at"] < now:
                return None
            code = "QF-" + secrets.token_hex(6).upper()
            await db.execute("BEGIN IMMEDIATE")
            try:
                await db.execute("UPDATE getlink_sessions SET status='verified' WHERE session_id=?", (session_id,))
                await db.execute("INSERT INTO getlink_codes(code_hash,session_id,user_id,expires_at) VALUES (?,?,?,?)",
                                 (_h(code), session_id, s["user_id"], now + CODE_TTL))
                await db.execute("COMMIT")
            except BaseException:
                await db.execute("ROLLBACK")
                raise
        return code

    async def redeem(self, user_id: int, code: str, now: float | None = None):
        """Returns (ok, message, new_balance)."""
        now = now or time.time()
        h = _h(code)
        async with self.l.db.execute("SELECT * FROM getlink_codes WHERE code_hash=?", (h,)) as c:
            row = await c.fetchone()
        if not row or row["user_id"] != user_id:
            return False, "Invalid code.", None
        if row["redeemed_at"]:
            return False, "This code was already redeemed.", None
        if row["expires_at"] < now:
            return False, "This code has expired.", None
        db = self.l.db

        async def mark():
            cur = await db.execute("UPDATE getlink_codes SET redeemed_at=? WHERE code_hash=? AND redeemed_at IS NULL",
                                   (now, h))
            if cur.rowcount != 1:
                raise DuplicateOperation("redeemed")
            await db.execute("UPDATE getlink_sessions SET status='redeemed' WHERE session_id=?", (row["session_id"],))
        try:
            res = await self.l.transact(
                [dict(user_id=user_id, delta=self.reward, tx_type="getlink", related_id=row["session_id"])], extra=mark)
        except DuplicateOperation:
            return False, "This code was already redeemed.", None
        return True, f"Redeemed! +{self.reward} QF Coins.", res[0][1]
