import asyncio
import logging
import discord
from discord.ext import commands, tasks
from config import GAMES
from bot.security import embed
from bot.leaderboard_core import LeaderboardCore
from bot.match_core import today_ist

log = logging.getLogger("qf.leaderboard")
MEDALS = {1: "🥇", 2: "🥈", 3: "🥉"}


class Leaderboard(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.core = LeaderboardCore(bot.ledger, bot.settings)
        self.guard = asyncio.Lock()

    async def cog_load(self):
        self.loop.start()

    async def cog_unload(self):
        self.loop.cancel()

    @tasks.loop(seconds=60)
    async def loop(self):
        await self.run_payouts()

    @loop.before_loop
    async def _wait(self):
        await self.bot.wait_until_ready()

    async def run_payouts(self):
        """Finalizes every completed IST day (catches up after downtime) and posts any unposted results."""
        async with self.guard:
            try:
                for day in await self.core.pending_days():
                    await self.core.finalize(day)   # None => already done; safe to repeat
                ch = self.bot.get_channel(self.bot.settings.leaderboard_channel_id)
                for day in await self.core.unposted():
                    rows = await self.core.results(day)
                    if ch is None:
                        log.error("leaderboard channel missing; results for %s stay unposted", day)
                        break
                    lines = [f"{MEDALS[r['rank']]} <@{r['user_id']}> — {r['points']} pts · **+{r['reward']} QF**" for r in rows]
                    await ch.send(embed=embed(f"🏆 Daily Leaderboard — {day}", "\n".join(lines) or "No qualifying players."))
                    await self.core.mark_posted(day)
            except Exception:
                log.exception("daily payout run failed (will retry)")

    @commands.group(invoke_without_command=True)
    @commands.cooldown(2, 10, commands.BucketType.user)
    async def leaderboard(self, ctx):
        async with self.bot.db.execute("SELECT user_id,balance FROM users ORDER BY balance DESC LIMIT 10") as c:
            rows = await c.fetchall()
        await ctx.send(embed=embed("💰 Richest players", "\n".join(f"{i}. <@{r['user_id']}> — {r['balance']:,} QF" for i, r in enumerate(rows, 1)) or "Empty."))

    @leaderboard.command(name="daily")
    async def lb_daily(self, ctx):
        day = today_ist(self.bot.settings.timezone)
        rows = await self.core.standings(day)
        pr = self.bot.settings.prize
        lines = [f"{i}. <@{r['user_id']}> — {r['points']} pts ({r['wins']} wins)" + (f" · prize {pr[i-1]}" if i <= 3 else "")
                 for i, r in enumerate(rows, 1)]
        await ctx.send(embed=embed(f"Today's standings ({day}, resets 12:00 AM IST)", "\n".join(lines) or "No points yet today."))

    @leaderboard.command(name="wins")
    async def lb_wins(self, ctx):
        await self._wins(ctx, None)

    @leaderboard.command(name="history")
    async def lb_hist(self, ctx):
        rows = await self.core.history()
        await ctx.send(embed=embed("Past daily winners", "\n".join(f"{r['day']} #{r['rank']} <@{r['user_id']}> (+{r['reward']})" for r in rows) or "None yet."))

    async def _wins(self, ctx, game):
        rows = await self.core.wins_board(game)
        t = f"Wins — {game}" if game else "Wins — all games"
        await ctx.send(embed=embed(t, "\n".join(f"{i}. <@{r['user_id']}> — {r['wins']}" for i, r in enumerate(rows, 1)) or "No wins yet."))

    @leaderboard.command(name="guess")
    async def lb_guess(self, ctx): await self._wins(ctx, "guess")

    @leaderboard.command(name="rps")
    async def lb_rps(self, ctx): await self._wins(ctx, "rps")

    @leaderboard.command(name="ttt")
    async def lb_ttt(self, ctx): await self._wins(ctx, "ttt")

    @leaderboard.command(name="word")
    async def lb_word(self, ctx): await self._wins(ctx, "word")


async def setup(bot):
    await bot.add_cog(Leaderboard(bot))
