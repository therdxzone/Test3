import discord
from discord.ext import commands
from bot.security import embed
from bot.stats import player_stats, recent_matches


class Profile(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    @commands.cooldown(2, 10, commands.BucketType.user)
    async def profile(self, ctx, member: discord.Member = None):
        m = member or ctx.author
        st = await player_stats(self.bot.db, m.id)
        bal = await self.bot.ledger.balance(m.id)
        e = embed(f"Profile — {m.display_name}")
        e.add_field(name="Balance", value=f"{bal:,} QF")
        e.add_field(name="Matches", value=f"{st['played']} (W{st['wins']}/L{st['losses']}/D{st['draws']})")
        e.add_field(name="Win rate", value=f"{st['win_pct']}%")
        e.add_field(name="Streak", value=f"{st['cur']} (best {st['best']})")
        e.add_field(name="Earned from matches", value=f"{st['earned']:,} QF")
        e.add_field(name="Today's points", value=str(st["today_points"]))
        per = "\n".join(f"{g}: {st['wins_by'].get(g,0)}W / {st['losses_by'].get(g,0)}L" for g in ("guess", "rps", "ttt", "word"))
        e.add_field(name="Per game", value=per, inline=False)
        if st["placements"]:
            e.add_field(name="Daily placements", value="\n".join(f"{p['day']}: #{p['rank']} ({p['points']} pts)" for p in st["placements"]), inline=False)
        await ctx.send(embed=e)

    @commands.command()
    @commands.cooldown(2, 10, commands.BucketType.user)
    async def history(self, ctx):
        rows = await recent_matches(self.bot.db, ctx.author.id)
        if not rows:
            return await ctx.send("No matches yet.")
        out = []
        for r in rows:
            opp = r["p2"] if r["p1"] == ctx.author.id else r["p1"]
            res = ("Draw" if r["status"] == "draw" else "Cancelled" if r["status"] == "cancelled"
                   else "Win" if r["winner"] == ctx.author.id else "Loss")
            out.append(f"#{r['match_id']} {r['game']} vs <@{opp}> — **{res}** ({r['pot']:,} pot)")
        await ctx.send(embed=embed("Recent matches", "\n".join(out)))


async def setup(bot):
    await bot.add_cog(Profile(bot))
