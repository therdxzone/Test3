import asyncio
from bot.match_core import MatchCore, today_ist
from bot.leaderboard_core import LeaderboardCore
from tests.test_matches import mk


async def _win(c, ledger, w, l, game="rps"):
    for u in (w, l):
        if await ledger.balance(u) < 100:
            await ledger.credit(u, 1000, "t")
    mid = await c.create(game, 200, w, l)
    await c.allocate_next(game)
    await c.finish(mid, w)
    await c.release(mid)


async def test_points_only_from_wins_and_pair_cap(ledger, settings):
    c = mk(ledger, settings)
    lb = LeaderboardCore(ledger, settings)
    for _ in range(7):
        await _win(c, ledger, 1, 2)
    day = today_ist(settings.timezone)
    top = await lb.standings(day)
    assert [(r["user_id"], r["points"]) for r in top] == [(1, 50)]   # cap of 5 wins vs same opponent
    await ledger.credit(3, 99999, "admin_add")                        # admin grant: no points
    assert len(await lb.standings(day)) == 1


async def test_prizes_300_200_100_once_and_tiebreak(ledger, settings):
    c = mk(ledger, settings)
    lb = LeaderboardCore(ledger, settings)
    await _win(c, ledger, 1, 9); await _win(c, ledger, 1, 8)   # user1: 20
    await _win(c, ledger, 2, 9); await _win(c, ledger, 3, 9)   # users 2,3: 10 each (2 reached first)
    await _win(c, ledger, 4, 9)                                # user 4: 10 -> 4th, no prize
    before = {u: await ledger.balance(u) for u in (1, 2, 3, 4)}
    day = today_ist(settings.timezone)
    rows = await lb.finalize(day)
    assert [(r[1], r[3]) for r in rows] == [(1, 300), (2, 200), (3, 100)]
    assert await lb.finalize(day) is None                       # restart/duplicate run pays nothing
    assert await ledger.balance(1) == before[1] + 300
    assert await ledger.balance(2) == before[2] + 200
    assert await ledger.balance(3) == before[3] + 100
    assert await ledger.balance(4) == before[4]
    assert len(await lb.results(day)) == 3
