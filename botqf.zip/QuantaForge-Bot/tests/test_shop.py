import asyncio
import pytest
from bot.shop_core import ShopCore, ShopError
from bot.ledger import DuplicateOperation


async def test_reserve_reject_refund_once(ledger, settings):
    s = ShopCore(ledger, settings)
    await ledger.credit(1, 1500, "t")
    rid = await s.request(1, "starter")
    assert await ledger.balance(1) == 500
    with pytest.raises(ShopError):
        await s.request(1, "Basic")                  # one open request
    await s.reject(rid, 99)
    assert await ledger.balance(1) == 1500
    with pytest.raises(DuplicateOperation):
        await s.reject(rid, 99)
    assert await ledger.balance(1) == 1500


async def test_insufficient_funds(ledger, settings):
    s = ShopCore(ledger, settings)
    await ledger.credit(1, 999, "t")
    with pytest.raises(ShopError):
        await s.request(1, "Starter")
    assert await ledger.balance(1) == 999


async def test_accept_without_backend_is_manual_not_success(ledger, settings):
    s = ShopCore(ledger, settings)
    settings.provision_url = ""
    await ledger.credit(1, 1000, "t")
    rid = await s.request(1, "Starter")
    status, sid, note = await s.accept(rid, 99)
    assert status == "manual" and sid is None
    with pytest.raises(DuplicateOperation):
        await s.accept(rid, 99)
    with pytest.raises(DuplicateOperation):
        await s.reject(rid, 99)                      # can't refund via reject after accept
    await s.refund_unprovisioned(rid, 99)
    with pytest.raises(DuplicateOperation):
        await s.refund_unprovisioned(rid, 99)
    assert await ledger.balance(1) == 1000


async def test_plan_catalogue_editable(ledger, settings):
    s = ShopCore(ledger, settings)
    assert len(await s.plans()) == 6
    await s.set_plan("Starter", 3, 20, 1500)
    assert (await s.plans())[0]["price"] == 1500 or any(p["price"] == 1500 for p in await s.plans())
    await s.disable_plan("ultra")
    assert len(await s.plans()) == 5
