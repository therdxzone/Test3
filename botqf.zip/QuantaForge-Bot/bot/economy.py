import time
import discord
from discord.ext import commands
from bot.security import embed


class Economy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, m: discord.Message):
        if m.guild is None or m.guild.id != self.bot.settings.guild_id:
            return
        if m.author.bot or m.webhook_id or not m.content or m.content.startswith(("&", "!")):
            return
        await self.bot.eco.count_message(m.author.id)

    @commands.command()
    @commands.cooldown(3, 10, commands.BucketType.user)
    async def balance(self, ctx, member: discord.Member = None):
        member = member or ctx.author
        if member.bot:
            return await ctx.send("Bots have no account.")
        bal = await self.bot.ledger.balance(member.id)
        await ctx.send(embed=embed("QF Coins", f"{member.mention}: **{bal:,}** QF"))

    @commands.command()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def daily(self, ctx):
        ok, bal, nxt = await self.bot.eco.claim_daily(ctx.author.id)
        if ok:
            await ctx.send(embed=embed("Daily reward", f"+{self.bot.settings.daily_reward} QF. Balance: **{bal:,}**"))
        else:
            await ctx.send(embed=embed("Daily reward", f"Already claimed. Next claim: <t:{int(nxt.timestamp())}:R>"))

    @commands.command()
    async def msg(self, ctx):
        counted, claimed, avail, prog = await self.bot.eco.progress(ctx.author.id)
        await ctx.send(embed=embed("Message progress",
                                   f"{prog}/{self.bot.settings.msg_batch} messages\nClaims available: **{avail}**"))

    @commands.command()
    @commands.cooldown(1, 5, commands.BucketType.user)
    async def claim(self, ctx):
        r = await self.bot.eco.claim_messages(ctx.author.id)
        if not r:
            return await ctx.send("No claim available. Check `&msg`.")
        base, bonus, bal = r
        extra = f" (+{bonus} bonus)" if bonus else ""
        await ctx.send(embed=embed("Claimed", f"+{base}{extra} QF. Balance: **{bal:,}**"))

    @commands.command()
    async def help(self, ctx):
        e = embed("QuantaForge — Help")
        e.add_field(name="Economy", value="`&balance` `&daily` `&msg` `&claim` `&invite` `&profile` `&history`", inline=False)
        e.add_field(name="Games", value="`&challenge @user guess|rps|ttt|word 200`", inline=False)
        e.add_field(name="Leaderboard", value="`&leaderboard` `&leaderboard daily` `&leaderboard wins`", inline=False)
        e.add_field(name="GetLink", value="`&getlink` `&code YOUR-CODE`\n*May be unavailable while the feature is OFF.*", inline=False)
        e.add_field(name="Shop", value="`!buy`", inline=False)
        if self.bot.settings.is_admin(ctx.author.id):
            e.add_field(name="Admin", value="`&addcoins` `&removecoins` `&setcoins` `&giveall` `&coinlogs` "
                        "`&addgetlink` `&getlink on|off|status` `&botstatus` `&matches` `&releasechannel` `&setplan` `&delplan` `&vpsrequests` `&vpsrefund` `&setconfig`", inline=False)
        await ctx.send(embed=e)


async def setup(bot):
    await bot.add_cog(Economy(bot))
