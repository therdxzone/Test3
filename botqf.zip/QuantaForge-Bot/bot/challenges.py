"""&challenge command, match runner for all four games, admin inspection."""
from __future__ import annotations
import asyncio
import logging
import random
import discord
from discord.ext import commands
from config import GAMES
from bot.security import embed, admin_log, admin_only
from bot.match_core import MatchCore, Busy, validate_pot, fee_for
from bot.ledger import InsufficientFunds, DuplicateOperation
from bot import channel_manager as cm
from games.guess import GuessGame
from games.rps import RPSGame, NAMES
from games.tictactoe import TTTGame
from games.word_scramble import WordGame

log = logging.getLogger("qf.match")
CHALLENGE_TIMEOUT = 120
RPS_WINDOW = 3          # seconds per round (spec)
TTT_MOVE_TIME = 10
WORD_ROUND_TIME = 20
GUESS_MAX = 8
GUESS_TIMEOUT = 300
TITLES = {"guess": "Number Guess Battle", "rps": "Rock Paper Scissors", "ttt": "Tic-Tac-Toe", "word": "Word Scramble Duel"}


class ChallengeView(discord.ui.View):
    def __init__(self, cog, ctx, target, game, pot):
        super().__init__(timeout=CHALLENGE_TIMEOUT)
        self.cog, self.ctx, self.target, self.game, self.pot = cog, ctx, target, game, pot
        self.message = None
        self.handled = False

    async def interaction_check(self, itx):
        if itx.user.id != self.target.id:
            await itx.response.send_message("Only the challenged player can answer this.", ephemeral=True)
            return False
        return True

    def _end(self):
        self.handled = True
        self.cog.pending.discard(self.ctx.author.id); self.cog.pending.discard(self.target.id)
        self.stop()

    @discord.ui.button(label="Accept", style=discord.ButtonStyle.success)
    async def accept(self, itx, button):
        if self.handled:
            return await itx.response.send_message("Already handled.", ephemeral=True)
        self._end()
        await itx.response.defer()
        try:
            await self.cog.core.create(self.game, self.pot, self.ctx.author.id, self.target.id)
        except InsufficientFunds:
            return await itx.edit_original_response(content="Challenge cancelled: a player can't cover their stake.", embed=None, view=None)
        except Busy:
            return await itx.edit_original_response(content="Challenge cancelled: a player is already in a match.", embed=None, view=None)
        await itx.edit_original_response(content=f"Challenge accepted! Stakes of {self.pot//2:,} QF reserved each.", embed=None, view=None)
        started = await self.cog.pump(self.game)
        if not started:
            await self.ctx.send(f"{self.ctx.author.mention} {self.target.mention} all {TITLES[self.game]} channels are busy — "
                                "your match is **waiting in the queue** and will start automatically.")

    @discord.ui.button(label="Decline", style=discord.ButtonStyle.danger)
    async def decline(self, itx, button):
        if self.handled:
            return await itx.response.send_message("Already handled.", ephemeral=True)
        self._end()
        await itx.response.edit_message(content="Challenge declined. No coins were charged.", embed=None, view=None)

    async def on_timeout(self):
        if not self.handled:
            self._end()
            if self.message:
                try:
                    await self.message.edit(content="Challenge expired. No coins were charged.", embed=None, view=None)
                except discord.HTTPException:
                    pass


class GuessModal(discord.ui.Modal, title="Your guess (1-100)"):
    num = discord.ui.TextInput(label="Number", max_length=3)

    def __init__(self, game, done):
        super().__init__()
        self.game, self.done = game, done

    async def on_submit(self, itx):
        try:
            n = int(str(self.num).strip())
        except ValueError:
            n = None
        r = self.game.guess(itx.user.id, n)
        used = self.game.count.get(itx.user.id, 0)
        txt = {"invalid": "Enter a whole number from 1 to 100.", "forbidden": "You are not in this match.",
               "out": "You have no guesses left.", "over": "The match is over.",
               "high": f"{n} is **too HIGH** ({used}/{self.game.max})", "low": f"{n} is **too LOW** ({used}/{self.game.max})",
               "win": f"🎯 {n} is correct!"}[r]
        await itx.response.send_message(txt, ephemeral=True)  # only the guesser sees it
        if r == "win" or self.game.exhausted:
            self.done.set()


class GuessView(discord.ui.View):
    def __init__(self, game, done):
        super().__init__(timeout=None)
        self.game, self.done = game, done

    @discord.ui.button(label="Make a guess", style=discord.ButtonStyle.primary)
    async def g(self, itx, button):
        if itx.user.id not in self.game.players:
            return await itx.response.send_message("You are not in this match.", ephemeral=True)
        await itx.response.send_modal(GuessModal(self.game, self.done))


class RPSView(discord.ui.View):
    def __init__(self, game, ev):
        super().__init__(timeout=None)
        self.game, self.ev = game, ev
        for mv, name in NAMES.items():
            b = discord.ui.Button(label=name, custom_id=f"rps{mv}")
            b.callback = self._cb(mv)
            self.add_item(b)

    def _cb(self, mv):
        async def cb(itx):
            if self.game.submit(itx.user.id, mv):
                await itx.response.send_message(f"Locked in: {NAMES[mv]}", ephemeral=True)
                if len(self.game.moves) == 2:
                    self.ev.set()
            else:
                await itx.response.send_message("Move not accepted (not in match or already submitted).", ephemeral=True)
        return cb


class TTTView(discord.ui.View):
    def __init__(self, game, moved, names):
        super().__init__(timeout=None)
        self.game, self.moved, self.names = game, moved, names
        for i in range(9):
            b = discord.ui.Button(label="\u200b", row=i // 3)
            b.callback = self._cb(i)
            self.add_item(b)

    def refresh(self):
        for i, b in enumerate(self.children):
            mark = self.game.board[i]
            b.label = mark or "\u200b"
            b.disabled = mark is not None or self.game.over
            b.style = (discord.ButtonStyle.danger if mark == "X" else discord.ButtonStyle.primary) if mark else discord.ButtonStyle.secondary

    def _cb(self, i):
        async def cb(itx):
            ok, err = self.game.move(itx.user.id, i + 1)
            if not ok:
                return await itx.response.send_message(err, ephemeral=True)
            self.refresh()
            await itx.response.edit_message(content=self.status(), view=self)
            self.moved.set()
        return cb

    def status(self):
        g = self.game
        if g.winner: return f"🏆 <@{g.winner}> wins!"
        if g.draw: return "Draw!"
        return f"<@{g.turn}>'s turn ({'X' if g.turn == g.x else 'O'}) — {TTT_MOVE_TIME}s"


class Challenges(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.core = MatchCore(bot.ledger, bot.settings)
        self.pending: set[int] = set()
        self.locks = {g: asyncio.Lock() for g in GAMES}
        self._recovered = False
        self.tasks: set[asyncio.Task] = set()

    # ---------- command ----------
    @commands.command()
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def challenge(self, ctx, target: discord.Member, game: str, pot: int):
        game = game.lower()
        if game not in GAMES: return await ctx.send(f"Game must be one of: {', '.join(GAMES)}.")
        if target.bot or target.id == ctx.author.id: return await ctx.send("Pick another real player.")
        err = validate_pot(pot, self.bot.settings.max_stake)
        if err: return await ctx.send(err)
        if not self.bot.settings.game_channels.get(game): return await ctx.send("No channels configured for that game.")
        stake = pot // 2
        for u in (ctx.author, target):
            if await self.bot.ledger.balance(u.id) < stake:
                return await ctx.send(f"{u.mention} needs at least {stake:,} QF to join this match.")
            if u.id in self.pending or await self.core.user_busy(u.id):
                return await ctx.send(f"{u.mention} already has a pending challenge or match.")
        self.pending.update((ctx.author.id, target.id))
        view = ChallengeView(self, ctx, target, game, pot)
        e = embed(f"⚔️ {TITLES[game]}", f"{ctx.author.mention} challenges {target.mention}\nPot: **{pot:,}** QF "
                  f"({stake:,} each) · winner fee {fee_for(pot)}\nExpires in 2 minutes. No coins are taken until accepted.")
        view.message = await ctx.send(content=target.mention, embed=e, view=view)

    # ---------- scheduling ----------
    async def pump(self, game: str) -> bool:
        started = False
        async with self.locks[game]:
            while True:
                r = await self.core.allocate_next(game)
                if not r:
                    break
                started = True
                t = asyncio.create_task(self.run_match(*r))
                self.tasks.add(t); t.add_done_callback(self.tasks.discard)
        return started

    async def run_match(self, mid: int, channel_id: int):
        m = await self.core.get(mid)
        guild = self.bot.get_guild(self.bot.settings.guild_id)
        channel = guild.get_channel(channel_id) if guild else None
        members = [guild.get_member(m["p1"]), guild.get_member(m["p2"])] if guild else [None, None]
        released_ok = True
        try:
            try:
                if None in members:
                    raise cm.ChannelError("a player left the server")
                await cm.open_channel(channel, members)
            except cm.ChannelError as e:
                log.error("match %s cannot start: %s", mid, e)
                await self.core.finish(mid, None, "cancelled", f"setup failed: {e}")
                await admin_log(self.bot, f"Match #{mid} cancelled & refunded: {e}")
                await self._notify(m, f"Match cancelled and stakes refunded: {e}")
                return
            await channel.send(f"{members[0].mention} vs {members[1].mention} — **{TITLES[m['game']]}** for {m['pot']:,} QF. Good luck!")
            try:
                winner, note = await getattr(self, f"_run_{m['game']}")(channel, m, members)
            except Exception:
                log.exception("match %s crashed; refunding", mid)
                winner, note = None, "internal error"
            try:
                payout = await self.core.finish(mid, winner, "draw" if note != "internal error" else "cancelled", note)
            except DuplicateOperation:
                return
            msg = (f"🏆 <@{winner}> wins **{payout:,}** QF (fee {m['fee']})!" if winner
                   else f"🤝 No winner ({note}). Stakes refunded, no fee.")
            await channel.send(msg)
            rc = self.bot.get_channel(self.bot.settings.game_results_channel_id)
            if rc:
                await rc.send(f"{TITLES[m['game']]} #{mid}: " + msg)
        finally:
            if channel is not None:
                released_ok = await cm.close_channel(channel, [x for x in members if x])
            if released_ok:
                await self.core.release(mid)
            else:
                await admin_log(self.bot, f"Channel {channel_id} could not be cleaned (match #{mid}); it stays locked. "
                                "Fix permissions then run `&releasechannel <id>`.")
            await self.pump(m["game"])

    async def _notify(self, m, text):
        ch = self.bot.get_channel(self.bot.settings.game_results_channel_id)
        if ch:
            await ch.send(f"<@{m['p1']}> <@{m['p2']}> {text}")

    # ---------- games ----------
    async def _run_guess(self, ch, m, members):
        ids = (m["p1"], m["p2"])
        game = GuessGame(random.randint(1, 100), ids, GUESS_MAX)
        done = asyncio.Event()
        await ch.send(embed=embed("Number Guess Battle", f"Guess the secret number 1-100. {GUESS_MAX} guesses each, "
                      f"{GUESS_TIMEOUT//60} min limit. Feedback is private to you."), view=GuessView(game, done))
        try:
            await asyncio.wait_for(done.wait(), GUESS_TIMEOUT)
        except asyncio.TimeoutError:
            pass
        if game.winner:
            return game.winner, "exact guess"
        return None, f"no exact guess (secret was {game.secret})"

    async def _run_rps(self, ch, m, members):
        game = RPSGame((m["p1"], m["p2"]))
        void = 0
        while game.winner is None:
            game.new_round()
            ev = asyncio.Event()
            view = RPSView(game, ev)
            msg = await ch.send(f"Round: pick within {RPS_WINDOW}s (moves are hidden)", view=view)
            try:
                await asyncio.wait_for(ev.wait(), RPS_WINDOW)
            except asyncio.TimeoutError:
                pass
            for b in view.children: b.disabled = True
            await msg.edit(view=view)
            n = len(game.moves)
            if n == 2:
                void = 0
                w = game.resolve()
                mv = " vs ".join(f"<@{p}>: {NAMES[game.moves[p]]}" for p in game.players)
                await ch.send(f"{mv}\n" + (f"Point to <@{w}>" if w else "Tie — no point") + f"\nScore: " +
                              " – ".join(f"<@{p}> {s}" for p, s in game.score.items()))
            elif n == 1:
                void = 0
                p = next(iter(game.moves)); game.award(p)
                await ch.send(f"<@{p}> locked in; opponent missed. Point to <@{p}>.\nScore: " +
                              " – ".join(f"<@{q}> {s}" for q, s in game.score.items()))
            else:
                void += 1
                await ch.send("Nobody moved — round void.")
                if void >= 3:
                    return None, "abandoned (3 empty rounds)"
        return game.winner, "first to 5"

    async def _run_ttt(self, ch, m, members):
        game = TTTGame(m["p1"], m["p2"])
        moved = asyncio.Event()
        view = TTTView(game, moved, None)
        view.refresh()
        await ch.send(f"X = <@{game.x}>, O = <@{game.o}>\n" + view.status(), view=view)
        while not game.over:
            moved.clear()
            try:
                await asyncio.wait_for(moved.wait(), TTT_MOVE_TIME)
            except asyncio.TimeoutError:
                loser = game.turn
                winner = game.o if loser == game.x else game.x
                for b in view.children: b.disabled = True
                await ch.send(f"⏱ <@{loser}> ran out of time and forfeits.")
                return winner, "timeout forfeit"
        for b in view.children: b.disabled = True
        return (game.winner, "line") if game.winner else (None, "board full")

    async def _run_word(self, ch, m, members):
        game = WordGame((m["p1"], m["p2"]))
        loop = asyncio.get_running_loop()
        idle = 0
        while game.winner is None:
            scr, hint = game.new_round()
            await ch.send(embed=embed("Word Scramble", f"**{scr.upper()}**\nHint: {hint}\n{WORD_ROUND_TIME}s"))
            end = loop.time() + WORD_ROUND_TIME
            scorer = None
            while game.open:
                left = end - loop.time()
                if left <= 0: break
                try:
                    msg = await self.bot.wait_for("message", timeout=left, check=lambda x: x.channel.id == ch.id and x.author.id in game.players)
                except asyncio.TimeoutError:
                    break
                if game.answer(msg.author.id, msg.content):
                    scorer = msg.author.id
            word = game.word; game.close_round()
            idle = 0 if scorer else idle + 1
            await ch.send((f"✅ <@{scorer}> got **{word}**!" if scorer else f"Time! The word was **{word}**.") +
                          "\nScore: " + " – ".join(f"<@{p}> {s}" for p, s in game.score.items()))
            if idle >= 3:
                return None, "abandoned (3 unanswered rounds)"
        return game.winner, "first to 5"

    # ---------- recovery & admin ----------
    @commands.Cog.listener()
    async def on_ready(self):
        if self._recovered:
            return
        self._recovered = True
        guild = self.bot.get_guild(self.bot.settings.guild_id)
        for m in await self.core.list_matches(("active",)):
            # Policy: matches that were running during a restart cannot resume safely -> cancel + refund both.
            try:
                await self.core.finish(m["match_id"], None, "cancelled", "bot restarted")
            except DuplicateOperation:
                pass
            ch = guild.get_channel(m["channel_id"]) if guild and m["channel_id"] else None
            ok = True
            if ch:
                ok = await cm.close_channel(ch, [x for x in (guild.get_member(m["p1"]), guild.get_member(m["p2"])) if x])
            if ok:
                await self.core.release(m["match_id"])
            await self._notify(m, "Your match was interrupted by a bot restart and your stake was refunded.")
        for g in GAMES:
            await self.pump(g)

    @commands.command(aliases=["queue", "channels"])
    @admin_only()
    async def matches(self, ctx):
        rows = await self.core.list_matches()
        assign = await self.core.assignments()
        lines = [f"#{r['match_id']} {r['game']} {r['status']} <@{r['p1']}> vs <@{r['p2']}> pot {r['pot']}"
                 f"{' ch '+str(r['channel_id']) if r['channel_id'] else ''}" for r in rows] or ["No active or queued matches."]
        free = [f"{g}: " + ", ".join(f"{c}{'🔒' if c in assign else '✅'}" for c in ids)
                for g, ids in self.bot.settings.game_channels.items()]
        await ctx.send(embed=embed("Matches & channels", "\n".join(lines) + "\n\n" + "\n".join(free)))

    @commands.command()
    @admin_only()
    async def releasechannel(self, ctx, channel_id: int):
        await self.core.force_release_channel(channel_id)
        await self.bot.ledger.audit(ctx.author.id, "releasechannel", str(channel_id))
        await ctx.send("Channel released. Pending matches will be assigned.")
        for g in GAMES: await self.pump(g)


async def setup(bot):
    await bot.add_cog(Challenges(bot))
