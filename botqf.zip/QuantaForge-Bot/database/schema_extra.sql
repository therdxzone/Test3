CREATE TABLE IF NOT EXISTS matches (
  match_id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref TEXT NOT NULL UNIQUE,
  game TEXT NOT NULL,
  pot INTEGER NOT NULL,
  stake INTEGER NOT NULL,
  fee INTEGER NOT NULL,
  p1 INTEGER NOT NULL,
  p2 INTEGER NOT NULL,
  status TEXT NOT NULL,            -- queued|active|settled|draw|cancelled
  channel_id INTEGER,
  winner INTEGER,
  note TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  started_at TEXT,
  ended_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_matches_status ON matches(status, game, match_id);
CREATE TABLE IF NOT EXISTS channel_assign (
  channel_id INTEGER PRIMARY KEY,
  match_id INTEGER NOT NULL UNIQUE REFERENCES matches(match_id)
);
CREATE TABLE IF NOT EXISTS daily_points (
  day TEXT NOT NULL, user_id INTEGER NOT NULL,
  points INTEGER NOT NULL DEFAULT 0, wins INTEGER NOT NULL DEFAULT 0, last_at REAL NOT NULL DEFAULT 0,
  PRIMARY KEY (day, user_id)
);
CREATE TABLE IF NOT EXISTS daily_pair (
  day TEXT NOT NULL, winner INTEGER NOT NULL, loser INTEGER NOT NULL, wins INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (day, winner, loser)
);
CREATE TABLE IF NOT EXISTS daily_results (
  day TEXT NOT NULL, rank INTEGER NOT NULL, user_id INTEGER NOT NULL, points INTEGER NOT NULL, reward INTEGER NOT NULL,
  PRIMARY KEY (day, rank)
);
CREATE TABLE IF NOT EXISTS daily_payout_status (
  day TEXT PRIMARY KEY, finalized_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, posted INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS vps_plans (
  name TEXT PRIMARY KEY, ram_gb INTEGER NOT NULL, storage_gb INTEGER NOT NULL, price INTEGER NOT NULL CHECK (price > 0),
  active INTEGER NOT NULL DEFAULT 1
);
INSERT OR IGNORE INTO vps_plans(name,ram_gb,storage_gb,price) VALUES
  ('Starter',2,15,1000),('Basic',4,25,2000),('Standard',8,50,4000),('Advanced',12,60,6000),('Pro',16,80,8000),('Ultra',24,100,12000);
CREATE TABLE IF NOT EXISTS vps_requests (
  request_id INTEGER PRIMARY KEY AUTOINCREMENT,
  ref TEXT NOT NULL UNIQUE, user_id INTEGER NOT NULL, plan TEXT NOT NULL, ram_gb INTEGER NOT NULL,
  storage_gb INTEGER NOT NULL, price INTEGER NOT NULL,
  status TEXT NOT NULL,   -- pending|rejected|provisioning|provisioned|manual|refunded
  server_id TEXT, note TEXT, message_id INTEGER, decided_by INTEGER,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, decided_at TEXT
);
