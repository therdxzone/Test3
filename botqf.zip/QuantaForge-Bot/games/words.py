"""Word list for Word Scramble (separate from the engine). (word, hint). Edit freely."""
WORDS = [
    ("python", "A popular programming language"), ("server", "Hosts websites and bots"),
    ("planet", "Orbits a star"), ("garden", "Where flowers grow"), ("rocket", "Travels to space"),
    ("dragon", "Mythical fire-breather"), ("castle", "A king's home"), ("pirate", "Sails the seas for treasure"),
    ("jungle", "Dense tropical forest"), ("market", "Place to buy and sell"), ("window", "Glass in a wall"),
    ("bridge", "Crosses a river"), ("silver", "Shiny metal, below gold"), ("island", "Land surrounded by water"),
    ("winter", "The coldest season"), ("coffee", "Morning caffeine drink"), ("guitar", "Six-string instrument"),
    ("keyboard", "You type on it"), ("database", "Stores structured data"), ("network", "Connected computers"),
    ("diamond", "Hardest natural gem"), ("volcano", "Mountain that erupts"), ("library", "Lots of books"),
    ("monster", "Scary creature"), ("thunder", "Sound after lightning"), ("crystal", "Clear mineral"),
    ("machine", "Mechanical device"), ("blanket", "Keeps you warm in bed"), ("lantern", "Portable light"),
    ("battery", "Stores electric charge"), ("compass", "Points north"), ("harvest", "Gathering crops"),
    ("fortress", "Strong military building"), ("universe", "Everything that exists"),
    ("adventure", "Exciting journey"), ("treasure", "Hidden riches"), ("lightning", "Flash in a storm"),
    ("mountain", "Very high landform"), ("champion", "Winner of a contest"), ("elephant", "Largest land animal"),
]
