"""Core coin ledger. All balance changes go through here, inside one serialized transaction."""
from __future__ import annotations
import asyncio
import aiosqlite


class InsufficientFunds(Exception):
    pass


class DuplicateOperation(Exception):
    pass


class Ledger:
    def __init__(self, db: aiosqlite.Connection):
        self.db = db
        self._lock = asyncio.Lock()  # one writer transaction at a time on the shared connection

    async def ensure_user(self, user_id: int) -> None:
        await self.db.execute("INSERT OR IGNORE INTO users(user_id) VALUES (?)", (user_id,))

    async def balance(self, user_id: int) -> int:
        await self.ensure_user(user_id)
        async with self.db.execute("SELECT balance FROM users WHERE user_id=?", (user_id,)) as c:
            return (await c.fetchone())["balance"]

    async def _apply(self, user_id, delta, tx_type, related_id=None, admin_id=None, reason=None, set_to=None):
        """Must be called inside an open transaction."""
        await self.db.execute("INSERT OR IGNORE INTO users(user_id) VALUES (?)", (user_id,))
        async with self.db.execute("SELECT balance FROM users WHERE user_id=?", (user_id,)) as c:
            prev = (await c.fetchone())["balance"]
        new = set_to if set_to is not None else prev + delta
        if new < 0:
            raise InsufficientFunds(f"balance {prev} cannot cover {delta}")
        try:
            await self.db.execute(
                "INSERT INTO transactions(user_id,amount,tx_type,prev_balance,new_balance,related_id,admin_id,reason)"
                " VALUES (?,?,?,?,?,?,?,?)",
                (user_id, new - prev, tx_type, prev, new, related_id, admin_id, reason))
        except aiosqlite.IntegrityError:
            raise DuplicateOperation(f"{tx_type}/{related_id} already applied")
        await self.db.execute("UPDATE users SET balance=? WHERE user_id=?", (new, user_id))
        return prev, new

    async def transact(self, ops: list[dict], extra=None) -> list[tuple[int, int]]:
        """Apply several balance ops atomically. `extra` is an optional async callable run in the same
        transaction (for claim markers etc.). Any failure rolls everything back."""
        async with self._lock:
            await self.db.execute("BEGIN IMMEDIATE")
            try:
                out = []
                for op in ops:
                    out.append(await self._apply(**op))
                if extra:
                    await extra()
                await self.db.execute("COMMIT")
                return out
            except BaseException:
                await self.db.execute("ROLLBACK")
                raise

    async def credit(self, user_id, amount, tx_type, **kw):
        if amount <= 0:
            raise ValueError("amount must be positive")
        return (await self.transact([dict(user_id=user_id, delta=amount, tx_type=tx_type, **kw)]))[0]

    async def debit(self, user_id, amount, tx_type, **kw):
        if amount <= 0:
            raise ValueError("amount must be positive")
        return (await self.transact([dict(user_id=user_id, delta=-amount, tx_type=tx_type, **kw)]))[0]

    async def set_balance(self, user_id, value, admin_id, reason):
        if value < 0:
            raise ValueError("balance cannot be negative")
        return (await self.transact([dict(user_id=user_id, delta=0, tx_type="admin_set",
                                          admin_id=admin_id, reason=reason, set_to=value)]))[0]

    async def give_all(self, amount, admin_id, reason):
        async with self.db.execute("SELECT user_id FROM users") as c:
            ids = [r["user_id"] for r in await c.fetchall()]
        ops = [dict(user_id=u, delta=amount, tx_type="admin_giveall", admin_id=admin_id, reason=reason) for u in ids]
        await self.transact(ops)
        return len(ids)

    async def history(self, user_id, limit=10):
        async with self.db.execute(
                "SELECT * FROM transactions WHERE user_id=? ORDER BY tx_id DESC LIMIT ?", (user_id, limit)) as c:
            return await c.fetchall()

    async def audit(self, admin_id, action, details=""):
        await self.db.execute("INSERT INTO admin_audit(admin_id,action,details) VALUES (?,?,?)",
                              (admin_id, action, details))
