"""Discord-side permission handling for the pre-existing private game channels (never creates/deletes channels)."""
import logging
import discord

log = logging.getLogger("qf.channels")


class ChannelError(Exception):
    pass


async def open_channel(channel, members):
    if channel is None or not isinstance(channel, discord.TextChannel):
        raise ChannelError("game channel not found or not a text channel")
    guild = channel.guild
    p = channel.permissions_for(guild.me)
    if not (p.view_channel and p.send_messages and p.manage_permissions):
        raise ChannelError("bot needs View Channel, Send Messages and Manage Permissions in this channel")
    if channel.permissions_for(guild.default_role).view_channel:
        raise ChannelError("channel is visible to @everyone; make it private before use")
    done = []
    try:
        for m in members:
            await channel.set_permissions(m, view_channel=True, send_messages=True, read_message_history=True,
                                          reason="QF match started")
            done.append(m)
    except discord.HTTPException as e:
        await close_channel(channel, done)
        raise ChannelError(f"could not grant access: {e}")


async def close_channel(channel, members) -> bool:
    ok = True
    for m in members:
        try:
            await channel.set_permissions(m, overwrite=None, reason="QF match ended")
        except (discord.HTTPException, AttributeError):
            ok = False
            log.exception("failed to remove access for %s on %s", getattr(m, "id", m), getattr(channel, "id", channel))
    return ok
