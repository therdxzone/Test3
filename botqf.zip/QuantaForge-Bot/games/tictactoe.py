LINES = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]


class TTTGame:
    def __init__(self, x: int, o: int):
        self.x, self.o = x, o
        self.board = [None] * 9
        self.turn = x
        self.winner = None
        self.draw = False

    @property
    def over(self):
        return self.winner is not None or self.draw

    def move(self, player: int, pos):
        """pos 1-9. Returns (ok, error)."""
        if player not in (self.x, self.o):
            return False, "You are not in this match."
        if self.over:
            return False, "Game is over."
        if player != self.turn:
            return False, "It is not your turn."
        if not isinstance(pos, int) or not 1 <= pos <= 9:
            return False, "Position must be 1-9."
        if self.board[pos - 1] is not None:
            return False, "That square is taken."
        mark = "X" if player == self.x else "O"
        self.board[pos - 1] = mark
        if any(all(self.board[i] == mark for i in l) for l in LINES):
            self.winner = player
        elif all(self.board):
            self.draw = True
        else:
            self.turn = self.o if player == self.x else self.x
        return True, ""

    def render(self) -> str:
        sym = lambda i: self.board[i] or str(i + 1)
        return "\n".join(" | ".join(sym(r * 3 + c) for c in range(3)) for r in range(3))
