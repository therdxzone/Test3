import discord
from discord.ext import commands
from bot.security import embed, admin_log, admin_only
from bot.ledger import InsufficientFunds


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def _target(self, ctx, member):
        if member.bot:
            await ctx.send("Cannot adjust a bot account.")
            return False
        return True

    @commands.command()
    @admin_only()
    async def addcoins(self, ctx, member: discord.Member, amount: int, *, reason: str = "no reason given"):
        if amount <= 0 or not await self._target(ctx, member):
            return await ctx.send("Amount must be positive.")
        _, new = await self.bot.ledger.credit(member.id, amount, "admin_add", admin_id=ctx.author.id, reason=reason)
        await self.bot.ledger.audit(ctx.author.id, "addcoins", f"{member.id} {amount} {reason}")
        await ctx.send(f"Added {amount:,} QF to {member.mention}. New balance: {new:,}")
        await admin_log(self.bot, f"[addcoins] {ctx.author.id} → {member.id}: +{amount} ({reason})")

    @commands.command()
    @admin_only()
    async def removecoins(self, ctx, member: discord.Member, amount: int, *, reason: str):
        if amount <= 0 or not await self._target(ctx, member):
            return await ctx.send("Amount must be positive.")
        try:
            _, new = await self.bot.ledger.debit(member.id, amount, "admin_remove", admin_id=ctx.author.id, reason=reason)
        except InsufficientFunds:
            return await ctx.send("User's balance is too low; balances cannot go negative.")
        await self.bot.ledger.audit(ctx.author.id, "removecoins", f"{member.id} {amount} {reason}")
        await ctx.send(f"Removed {amount:,} QF from {member.mention}. New balance: {new:,}")
        await admin_log(self.bot, f"[removecoins] {ctx.author.id} → {member.id}: -{amount} ({reason})")

    @commands.command()
    @admin_only()
    async def setcoins(self, ctx, member: discord.Member, amount: int, *, reason: str):
        if amount < 0 or not await self._target(ctx, member):
            return await ctx.send("Amount must be 0 or more.")
        _, new = await self.bot.ledger.set_balance(member.id, amount, ctx.author.id, reason)
        await self.bot.ledger.audit(ctx.author.id, "setcoins", f"{member.id} {amount} {reason}")
        await ctx.send(f"Set {member.mention} to {new:,} QF.")
        await admin_log(self.bot, f"[setcoins] {ctx.author.id} → {member.id}: ={amount} ({reason})")

    @commands.command()
    @admin_only()
    async def giveall(self, ctx, amount: int, *, reason: str = "giveall"):
        if amount <= 0:
            return await ctx.send("Amount must be positive.")
        n = await self.bot.ledger.give_all(amount, ctx.author.id, reason)
        await self.bot.ledger.audit(ctx.author.id, "giveall", f"{amount} x{n}")
        await ctx.send(f"Gave {amount:,} QF to {n} registered users.")
        await admin_log(self.bot, f"[giveall] {ctx.author.id}: +{amount} to {n} users")

    @commands.command()
    @admin_only()
    async def coinlogs(self, ctx, member: discord.Member):
        rows = await self.bot.ledger.history(member.id, 15)
        if not rows:
            return await ctx.send("No transactions.")
        lines = [f"`#{r['tx_id']}` {r['tx_type']} {r['amount']:+} ({r['prev_balance']}→{r['new_balance']})"
                 f"{' admin='+str(r['admin_id']) if r['admin_id'] else ''}" for r in rows]
        await ctx.send(embed=embed(f"Ledger — {member}", "\n".join(lines)))

    @commands.command()
    @admin_only()
    async def botstatus(self, ctx):
        s = self.bot.settings
        gl = await self.bot.getlink.config()
        miss = [n for g, ids in s.game_channels.items() for i, n in
                [(c, f"{g}:{c}") for c in ids] if ctx.guild.get_channel(i) is None]
        e = embed("Bot status")
        e.add_field(name="Guild", value=str(s.guild_id))
        e.add_field(name="Latency", value=f"{self.bot.latency*1000:.0f} ms")
        e.add_field(name="GetLink", value="ON" if await self.bot.getlink.is_on() else "OFF")
        e.add_field(name="Missing channels", value=", ".join(miss) or "none", inline=False)
        await ctx.send(embed=e)


async def setup(bot):
    await bot.add_cog(Admin(bot))
