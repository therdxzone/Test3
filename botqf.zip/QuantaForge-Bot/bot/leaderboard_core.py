"""Daily leaderboard: standings, tie-break, once-only prize payout.
Ranking: points (win_points per settled win; capped per opponent per day) DESC, then wins DESC,
then who reached their score earlier (last_at ASC), then lower user_id. Coins spent/granted never count."""
from __future__ import annotations
from bot.ledger import Ledger, DuplicateOperation
from bot.match_core import today_ist

ORDER = "points DESC, wins DESC, last_at ASC, user_id ASC"


class LeaderboardCore:
    def __init__(self, ledger: Ledger, settings):
        self.l, self.s = ledger, settings

    async def standings(self, day: str, limit: int = 10):
        async with self.l.db.execute(
                f"SELECT * FROM daily_points WHERE day=? AND points>0 ORDER BY {ORDER} LIMIT ?", (day, limit)) as c:
            return await c.fetchall()

    async def pending_days(self):
        today = today_ist(self.s.timezone)
        async with self.l.db.execute(
                "SELECT DISTINCT day FROM daily_points WHERE day<? AND day NOT IN (SELECT day FROM daily_payout_status) "
                "ORDER BY day", (today,)) as c:
            return [r["day"] for r in await c.fetchall()]

    async def finalize(self, day: str):
        """Saves final standings and pays prizes in ONE transaction. Returns list of (rank,user,points,reward) or None if
        that day was already finalized."""
        top = await self.standings(day, 3)
        db = self.l.db
        rows = [(i + 1, r["user_id"], r["points"], self.s.prize[i]) for i, r in enumerate(top)]

        async def mark():
            async with db.execute("SELECT 1 FROM daily_payout_status WHERE day=?", (day,)) as c:
                if await c.fetchone():
                    raise DuplicateOperation("day already finalized")
            await db.execute("INSERT INTO daily_payout_status(day) VALUES (?)", (day,))
            for rank, uid, pts, rew in rows:
                await db.execute("INSERT INTO daily_results(day,rank,user_id,points,reward) VALUES (?,?,?,?,?)",
                                 (day, rank, uid, pts, rew))
        try:
            await self.l.transact([dict(user_id=u, delta=rew, tx_type="leaderboard_prize", related_id=day)
                                   for _, u, _, rew in rows], extra=mark)
        except DuplicateOperation:
            return None
        return rows

    async def mark_posted(self, day):
        async def f():
            await self.l.db.execute("UPDATE daily_payout_status SET posted=1 WHERE day=?", (day,))
        await self.l.transact([], extra=f)

    async def unposted(self):
        async with self.l.db.execute("SELECT day FROM daily_payout_status WHERE posted=0 ORDER BY day") as c:
            return [r["day"] for r in await c.fetchall()]

    async def results(self, day: str):
        async with self.l.db.execute("SELECT * FROM daily_results WHERE day=? ORDER BY rank", (day,)) as c:
            return await c.fetchall()

    async def history(self, limit=7):
        async with self.l.db.execute("SELECT * FROM daily_results ORDER BY day DESC, rank LIMIT ?", (limit * 3,)) as c:
            return await c.fetchall()

    async def wins_board(self, game: str | None = None, limit=10):
        q = "SELECT winner AS user_id, COUNT(*) AS wins FROM matches WHERE status='settled'"
        args = []
        if game:
            q += " AND game=?"; args.append(game)
        q += " GROUP BY winner ORDER BY wins DESC, user_id LIMIT ?"
        async with self.l.db.execute(q, (*args, limit)) as c:
            return await c.fetchall()
